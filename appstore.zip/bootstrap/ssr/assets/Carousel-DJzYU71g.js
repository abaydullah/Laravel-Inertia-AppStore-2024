import { mergeProps, unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import { Carousel as Carousel$1, Navigation, Pagination, Slide } from "vue3-carousel";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-1tPrXgE0.js";
const _sfc_main = {
  __name: "Carousel",
  __ssrInlineRender: true,
  props: {
    apps: Object,
    breakpoints: {
      // 700px and up
      700: {
        itemsToShow: 3.5,
        snapAlign: "center"
      },
      // 1024 and up
      1024: {
        itemsToShow: 5,
        snapAlign: "start"
      }
    }
  },
  setup(__props) {
    const config = {
      itemsToShow: 3.95,
      wrapAround: true,
      transition: 500
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "w-full",
        style: { "resize": "horizontal", "overflow": "auto" }
      }, _attrs))} data-v-6843b1a0>`);
      _push(ssrRenderComponent(unref(Carousel$1), mergeProps(config, {
        autoplay: 2e3,
        "wrap-around": true
      }), {
        addons: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Navigation), null, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(unref(Pagination), null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Navigation)),
              createVNode(unref(Pagination))
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(__props.apps, (app) => {
              _push2(ssrRenderComponent(unref(Slide), { key: app }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  var _a, _b, _c, _d;
                  if (_push3) {
                    if ((_a = app == null ? void 0 : app.screenshots[0]) == null ? void 0 : _a.photo) {
                      _push3(`<a href="#" data-v-6843b1a0${_scopeId2}><div class="carousel__item" data-v-6843b1a0${_scopeId2}><img${ssrRenderAttr("src", (_b = app == null ? void 0 : app.screenshots[0]) == null ? void 0 : _b.photo)} alt="" class="w-full h-full object-cover" data-v-6843b1a0${_scopeId2}></div></a>`);
                    } else {
                      _push3(`<!---->`);
                    }
                  } else {
                    return [
                      ((_c = app == null ? void 0 : app.screenshots[0]) == null ? void 0 : _c.photo) ? (openBlock(), createBlock("a", {
                        key: 0,
                        href: "#"
                      }, [
                        createVNode("div", { class: "carousel__item" }, [
                          createVNode("img", {
                            src: (_d = app == null ? void 0 : app.screenshots[0]) == null ? void 0 : _d.photo,
                            alt: "",
                            class: "w-full h-full object-cover"
                          }, null, 8, ["src"])
                        ])
                      ])) : createCommentVNode("", true)
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(__props.apps, (app) => {
                return openBlock(), createBlock(unref(Slide), { key: app }, {
                  default: withCtx(() => {
                    var _a, _b;
                    return [
                      ((_a = app == null ? void 0 : app.screenshots[0]) == null ? void 0 : _a.photo) ? (openBlock(), createBlock("a", {
                        key: 0,
                        href: "#"
                      }, [
                        createVNode("div", { class: "carousel__item" }, [
                          createVNode("img", {
                            src: (_b = app == null ? void 0 : app.screenshots[0]) == null ? void 0 : _b.photo,
                            alt: "",
                            class: "w-full h-full object-cover"
                          }, null, 8, ["src"])
                        ])
                      ])) : createCommentVNode("", true)
                    ];
                  }),
                  _: 2
                }, 1024);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Home/Partials/Carousel.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Carousel = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-6843b1a0"]]);
export {
  Carousel as default
};
