import { ref, computed, watch, resolveComponent, mergeProps, unref, withCtx, createTextVNode, createVNode, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle, ssrRenderComponent, ssrIncludeBooleanAttr, ssrRenderClass, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import vue3StarRatings from "vue3-star-ratings";
import { useForm } from "@inertiajs/vue3";
import EmojiPicker from "vue3-emoji-picker";
import { _ as _sfc_main$2 } from "./TextInput-D7U8fbl4.js";
import { _ as _sfc_main$1 } from "./InputLabel-Dkex7vHI.js";
import { _ as _sfc_main$3 } from "./Modal-_hjahxgY.js";
const _sfc_main = {
  __name: "Review",
  __ssrInlineRender: true,
  props: {
    app: Object,
    errors: Object
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      app_id: props.app.id,
      rating: 0,
      review: "",
      name: ""
    });
    let editForm = useForm({
      _method: "PUT",
      id: "",
      app_id: props.app.id,
      rating: 0,
      review: "",
      name: "",
      ip: ""
    });
    ref(false);
    const isOpenDeleteBox = ref(false);
    const closeDeleteBox = () => {
      isOpenDeleteBox.value = false;
      editForm.reset();
    };
    const isComplete = ref(computed(() => getBoolean(form.review) && getBoolean(form.name) && form.rating > 0));
    function getBoolean(value) {
      if (value.toString().length) {
        return true;
      }
      return false;
    }
    const deleteReview = () => {
      editForm.delete(route("app.view.review.destroy", editForm.id), {
        preserveScroll: true,
        preserveState: false,
        onSuccess: () => {
          editForm.reset();
          isOpenDeleteBox.value = false;
        }
      });
    };
    watch(() => form.rating, (value) => {
      form.rating = Math.round(value);
    });
    watch(() => editForm.rating, (value) => {
      editForm.rating = Math.round(value);
    });
    function onChangeText(text) {
      form.review = text;
    }
    function onChangeTextUpdate(text) {
      editForm.review = text;
    }
    const reviewMax = ref(5);
    const reviewMore = (max) => {
      if (reviewMax.value + 5 < max) {
        reviewMax.value += 5;
      } else {
        reviewMax.value = max;
      }
    };
    const reviewLess = (max) => {
      reviewMax.value = 5;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ion_icon = resolveComponent("ion-icon");
      const _component_Button = resolveComponent("Button");
      const _component_DialogTitle = resolveComponent("DialogTitle");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full" }, _attrs))}><div class="overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2"><div class="px-4 py-2"><div class="flex w-full"><div class="flex flex-col w-2/12 items-center justify-items-center space-y-2"><span class="text-lg font-semibold">Rating</span><span class="text-5xl">${ssrInterpolate(__props.app.review_count.data.rating)}</span><span>${ssrInterpolate(__props.app.review_count.data.total)} Reviews</span></div><div class="w-10/12"><div class="flex space-x-3 items-center"><div>5</div><div class="bg-green-500 w-full h-2 rounded-md" style="${ssrRenderStyle(`width: ${__props.app.review_count.data.five}%`)}"></div></div><div class="flex space-x-3 items-center"><div>4</div><div class="bg-[#AED888] w-full h-2 rounded-md" style="${ssrRenderStyle(`width: ${__props.app.review_count.data.four}%`)}"></div></div><div class="flex space-x-3 items-center"><div>3</div><div class="bg-[#FFD935] w-full h-2 rounded-md" style="${ssrRenderStyle(`width: ${__props.app.review_count.data.three}%`)}"></div></div><div class="flex space-x-3 items-center"><div>2</div><div class="bg-[#FFB235] w-full h-2 rounded-md" style="${ssrRenderStyle(`width: ${__props.app.review_count.data.two}%`)}"></div></div><div class="flex space-x-3 items-center"><div>1</div><div class="bg-[#FF8C5A] w-full h-2 rounded-md" style="${ssrRenderStyle(`width: ${__props.app.review_count.data.one}%`)}"></div></div></div></div></div></div><div class="overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2"><div class="px-4 py-10">`);
      _push(ssrRenderComponent(unref(EmojiPicker), {
        native: true,
        pickerType: "textarea",
        class: "w-full",
        "onUpdate:text": onChangeText,
        text: unref(form).review
      }, null, _parent));
      _push(`<div class="w-full h-10 bg-gray-200 flex items-center justify-between px-10"><div class="flex items-center space-x-3">`);
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Name :`);
          } else {
            return [
              createTextVNode("Name :")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        modelValue: unref(form).name,
        "onUpdate:modelValue": ($event) => unref(form).name = $event
      }, null, _parent));
      _push(`</div><div class="">`);
      _push(ssrRenderComponent(unref(vue3StarRatings), {
        "star-size": "25",
        modelValue: unref(form).rating,
        "onUpdate:modelValue": ($event) => unref(form).rating = $event,
        inactiveColor: "#cbd5e1",
        in: "",
        numberOfStars: 5
      }, null, _parent));
      _push(`</div></div><div class="float-right mt-2"><button${ssrIncludeBooleanAttr(!isComplete.value) ? " disabled" : ""} class="${ssrRenderClass([{ "bg-green-500": isComplete.value }, "flex items-center space-x-2 disabled:bg-gray-400 text-gray-50 py-2 px-4 rounded-md disabled:cursor-not-allowed"])}"><span>Comment</span>`);
      _push(ssrRenderComponent(_component_ion_icon, { name: "send-outline" }, null, _parent));
      _push(`</button></div></div></div><div class="overflow-hidden shadow-sm sm:rounded-lg mt-2"><div class="divide-y space-y-2"><!--[-->`);
      ssrRenderList(__props.app.reviews.slice(0, reviewMax.value), (review) => {
        _push(`<div class=""><div class="flex rounded-md bg-white py-5 px-2"><div class="w-4/12 flex justify-between"><div class="w-4/12 mr-2"><img${ssrRenderAttr("src", review.icon)} width="80" alt="" class="rounded-md"></div><div class="w-8/12"><h4>${ssrInterpolate(review.name)}</h4><div>`);
        _push(ssrRenderComponent(unref(vue3StarRatings), {
          modelValue: review.rating,
          "onUpdate:modelValue": ($event) => review.rating = $event,
          "star-size": "15",
          inactiveColor: "#cbd5e1",
          disableClick: true
        }, null, _parent));
        _push(`</div><div>${ssrInterpolate(review.date)}</div></div></div><div class="w-6/12"><p>${ssrInterpolate(review.review)}</p></div><div class="w-2/12"><div class="flex space-x-3">`);
        if (review.ip === _ctx.$page.props.ip) {
          _push(`<button type="button" class="bg-blue-600 hover:bg-blue-800 py-1 px-2 text-white rounded-md font-semibold transition-all duration-300">Edit </button>`);
        } else {
          _push(`<!---->`);
        }
        if (review.ip === _ctx.$page.props.ip) {
          _push(`<button type="button" class="bg-red-600 hover:bg-red-700 py-1 px-2 text-white rounded-md font-semibold transition-all duration-300">Delete </button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div></div>`);
        if (review.id === unref(editForm).id) {
          _push(`<div class="inline-block w-full">`);
          _push(ssrRenderComponent(unref(EmojiPicker), {
            pickerType: "textarea",
            "onUpdate:text": onChangeTextUpdate,
            class: "w-full",
            text: review.review
          }, null, _parent));
          _push(`<div class="w-full h-10 bg-gray-200 flex items-center justify-between px-10"><div class="flex items-center space-x-3">`);
          _push(ssrRenderComponent(_sfc_main$1, null, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`Name :`);
              } else {
                return [
                  createTextVNode("Name :")
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(ssrRenderComponent(_sfc_main$2, {
            modelValue: unref(editForm).name,
            "onUpdate:modelValue": ($event) => unref(editForm).name = $event
          }, null, _parent));
          _push(`</div><div class="">`);
          _push(ssrRenderComponent(unref(vue3StarRatings), {
            "star-size": "25",
            modelValue: unref(editForm).rating,
            "onUpdate:modelValue": ($event) => unref(editForm).rating = $event,
            inactiveColor: "#cbd5e1",
            in: "",
            numberOfStars: 5
          }, null, _parent));
          _push(`</div></div><div class="flex justify-between mt-2"><button class="flex items-center space-x-2 text-gray-50 py-2 px-4 rounded-md bg-red-500"><span>Cancel</span>`);
          _push(ssrRenderComponent(_component_ion_icon, { name: "close-outline" }, null, _parent));
          _push(`</button><button${ssrIncludeBooleanAttr(!unref(editForm).isDirty) ? " disabled" : ""} class="${ssrRenderClass([{ "bg-green-500": unref(editForm).isDirty }, "flex items-center space-x-2 disabled:bg-gray-400 text-gray-50 py-2 px-4 rounded-md disabled:cursor-not-allowed"])}"><span>Update Comment</span>`);
          _push(ssrRenderComponent(_component_ion_icon, { name: "send-outline" }, null, _parent));
          _push(`</button></div></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      });
      _push(`<!--]--></div>`);
      if (__props.app.reviews.length > 5) {
        _push(`<div class="text-center pt-5 border-t">`);
        if (reviewMax.value !== __props.app.reviews.length) {
          _push(ssrRenderComponent(_component_Button, {
            class: "px-32 py-2 bg-gray-50 border-2 border-green-500 hover:border-green-200 rounded-md hover:bg-green-500 hover:text-gray-50 transition-all duration-300",
            onClick: ($event) => reviewMore(__props.app.reviews.length)
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Show More `);
              } else {
                return [
                  createTextVNode(" Show More ")
                ];
              }
            }),
            _: 1
          }, _parent));
        } else {
          _push(ssrRenderComponent(_component_Button, {
            class: "px-32 py-2 bg-gray-50 border-2 border-green-500 hover:border-green-200 rounded-md hover:bg-green-500 hover:text-gray-50 transition-all duration-300",
            onClick: ($event) => reviewLess(__props.app.reviews.length)
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(` Show Less `);
              } else {
                return [
                  createTextVNode(" Show Less ")
                ];
              }
            }),
            _: 1
          }, _parent));
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      _push(ssrRenderComponent(_sfc_main$3, { show: isOpenDeleteBox.value }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="pb-10 m-10 border-x border-t rounded-md"${_scopeId}><div class="flex justify-between justify-items-center items-center p-1 mb-2 rounded-md"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_DialogTitle, {
              as: "h3",
              class: "text-lg font-medium leading-6 text-gray-900"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Delete Review `);
                } else {
                  return [
                    createTextVNode(" Delete Review ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}><button type="button" class="text-5xl leading-6 text-gray-400 font-normal" data-bs-dismiss="modal" aria-label="Close"${_scopeId}> × </button></div></div><hr${_scopeId}><div class="bg-red-100 p-5 text-red-700 space-y-2 rounded-md"${_scopeId}><h2 class="flex space-x-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_ion_icon, {
              name: "alert-circle-outline",
              class: "text-3xl"
            }, null, _parent2, _scopeId));
            _push2(` <span class="text-2xl"${_scopeId}>Delete Review</span></h2><p class="px-10"${_scopeId}>You are sure you want to delete It?</p></div><div class="mt-4 space-x-2 float-end"${_scopeId}><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"${_scopeId}> Delete </button><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"${_scopeId}>Cancel </button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "pb-10 m-10 border-x border-t rounded-md" }, [
                createVNode("div", { class: "flex justify-between justify-items-center items-center p-1 mb-2 rounded-md" }, [
                  createVNode(_component_DialogTitle, {
                    as: "h3",
                    class: "text-lg font-medium leading-6 text-gray-900"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Delete Review ")
                    ]),
                    _: 1
                  }),
                  createVNode("div", null, [
                    createVNode("button", {
                      type: "button",
                      class: "text-5xl leading-6 text-gray-400 font-normal",
                      onClick: closeDeleteBox,
                      "data-bs-dismiss": "modal",
                      "aria-label": "Close"
                    }, " × ")
                  ])
                ]),
                createVNode("hr"),
                createVNode("div", { class: "bg-red-100 p-5 text-red-700 space-y-2 rounded-md" }, [
                  createVNode("h2", { class: "flex space-x-2" }, [
                    createVNode(_component_ion_icon, {
                      name: "alert-circle-outline",
                      class: "text-3xl"
                    }),
                    createTextVNode(),
                    createVNode("span", { class: "text-2xl" }, "Delete Review")
                  ]),
                  createVNode("p", { class: "px-10" }, "You are sure you want to delete It?")
                ]),
                createVNode("div", { class: "mt-4 space-x-2 float-end" }, [
                  createVNode("button", {
                    type: "button",
                    class: "inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                    onClick: deleteReview
                  }, " Delete "),
                  createVNode("button", {
                    type: "button",
                    class: "inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                    onClick: closeDeleteBox
                  }, "Cancel ")
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/App/Partials/Review.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
