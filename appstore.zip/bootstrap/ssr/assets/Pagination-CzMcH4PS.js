import { mergeProps, unref, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderComponent } from "vue/server-renderer";
import { Link } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "Pagination",
  __ssrInlineRender: true,
  props: {
    meta: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<nav${ssrRenderAttrs(mergeProps({
        class: "flex items-center flex-column flex-wrap md:flex-row justify-between py-4 px-2",
        "aria-label": "Table navigation"
      }, _attrs))}><span class="text-sm font-normal text-gray-500 dark:text-gray-400 mb-4 md:mb-0 block w-full md:inline md:w-auto">Showing <span class="font-semibold text-gray-900 dark:text-white">${ssrInterpolate(__props.meta.from)}-${ssrInterpolate(__props.meta.to)}</span> of <span class="font-semibold text-gray-900 dark:text-white">${ssrInterpolate(__props.meta.total)}</span></span><ul class="inline-flex -space-x-px rtl:space-x-reverse text-sm h-8"><!--[-->`);
      ssrRenderList(__props.meta.links, (link) => {
        _push(`<li>`);
        _push(ssrRenderComponent(unref(Link), {
          href: link.url ?? "",
          class: [{ "!bg-slate-600 !text-gray-50 !border-2 !text-2xl": link.active, "!bg-gray-200 cursor-not-allowed": !link.url }, "flex items-center justify-center px-3 h-8 ms-0 leading-tight text-gray-500 bg-white border border-gray-300 rounded-s-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"],
          "preserve-scroll": ""
        }, null, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></nav>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Pagination.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
