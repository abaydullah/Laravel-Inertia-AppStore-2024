import { watch, ref, resolveComponent, unref, withCtx, createVNode, openBlock, createBlock, createCommentVNode, withDirectives, vModelText, withModifiers, toDisplayString, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderStyle, ssrRenderList } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-DnYYwDfw.js";
import { useForm, Head, router } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Checkbox-CixedilU.js";
/* empty css                    */
import VSelect from "vue-select";
import vue3StarRatings from "vue3-star-ratings";
import "./ApplicationLogo-3H3I4iid.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./NavLink-CscBEwLF.js";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    apps: Object,
    app: Object,
    status: Number,
    sort: String,
    search: String,
    type: Number,
    categories: Object,
    developers: Object,
    developer: Object,
    category: Object,
    errors: Object
  },
  setup(__props) {
    const props = __props;
    const form = useForm({});
    watch(() => form.name, (name) => {
      form.slug = name.toLowerCase().replace(/[^\w ]+/g, "").replace(/ +/g, "-");
    });
    const loading = ref(false);
    const search = ref(props.search);
    const filterApps = () => {
      let searchQuery = search.value;
      router.post(route("admin.scrape.index"), { searchQuery }, {
        preserveState: true,
        preserveScroll: true,
        replace: true,
        onSuccess: (data) => {
          loading.value = false;
        }
      });
    };
    const category = ref(props.category);
    const developer = ref(props.developer);
    const filterAppsByCategory = () => {
      let categoryQuery = category.value;
      router.post(route("admin.scrape.index"), { categoryQuery }, {
        preserveState: true,
        preserveScroll: true,
        replace: true,
        onSuccess: (data) => {
          loading.value = false;
        }
      });
    };
    const filterAppsByDeveloper = () => {
      let developerQuery = developer.value;
      router.post(route("admin.scrape.index"), { developerQuery }, {
        preserveState: true,
        preserveScroll: true,
        replace: true,
        onSuccess: (data) => {
          loading.value = false;
        }
      });
    };
    const checkedApps = ref([]);
    const checkedApp = (app) => {
      if (app.checked) {
        checkedApps.value.push(app);
      } else {
        checkedApps.value.splice(checkedApps.value.indexOf(app), 1);
      }
    };
    const checkAll = ref(false);
    const checkedAll = () => {
      checkAll.value = true;
      props.apps.filter((app) => {
        app.checked = true;
        checkedApps.value.push(app);
      });
    };
    const uncheckedAll = () => {
      checkAll.value = false;
      props.apps.filter((app) => {
        app.checked = false;
        checkedApps.value.splice(checkedApps.value.indexOf(app), 1);
      });
    };
    const saveAll = () => {
      let data = checkedApps.value;
      router.post(route("admin.scrape.store"), { data }, {
        preserveState: true,
        preserveScroll: true,
        replace: true,
        onSuccess: (data2) => {
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ion_icon = resolveComponent("ion-icon");
      const _component_Header = resolveComponent("Header");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Apps" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-xl font-semibold leading-tight text-gray-800"${_scopeId}> Apps </h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-xl font-semibold leading-tight text-gray-800" }, " Apps ")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="bg-white shadow-sm sm:rounded-lg"${_scopeId}>`);
            if (loading.value) {
              _push2(`<div class="fixed top-0 flex items-center justify-center h-screen z-40 opacity-60 inset-1 w-full bg-slate-900"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_ion_icon, {
                name: "sync",
                class: "absolute top-1/2 right-[40%] animate-spin text-9xl text-red-100 font-extrabold"
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="p-6 text-gray-900"${_scopeId}><div id="content" class=""${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Header, { title: "main.app-list" }, null, _parent2, _scopeId));
            _push2(`<div class="relative shadow-md sm:rounded-lg mt-5"${_scopeId}><div class="flex items-center justify-between flex-wrap md:flex-row space-y-4 md:space-y-0 pb-4 bg-white dark:bg-gray-900"${_scopeId}><div class="flex space-x-3"${_scopeId}><div${_scopeId}><div class="relative"${_scopeId}><div class="absolute inset-y-0 rtl:inset-r-0 start-0 flex items-center ps-3 pointer-events-none"${_scopeId}><svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20"${_scopeId}><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"${_scopeId}></path></svg></div><input${ssrRenderAttr("value", search.value)} type="text" id="table-search-users" class="block p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg w-80 bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Search for App"${_scopeId}></div></div><div${_scopeId}><button type="button" class="rounded-md bg-blue-700 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"${_scopeId}> Search </button></div></div><div class="flex space-x-3"${_scopeId}><div class=""${_scopeId}>`);
            _push2(ssrRenderComponent(unref(VSelect), {
              options: __props.categories,
              reduce: (category2) => category2,
              label: "name",
              class: "style-chooser w-64",
              modelValue: category.value,
              "onUpdate:modelValue": ($event) => category.value = $event
            }, null, _parent2, _scopeId));
            if (__props.errors.type) {
              _push2(`<span class="text-lg text-red-600 font-semibold"${_scopeId}>${ssrInterpolate(__props.errors.type)}</span>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><button type="button" class="rounded-md bg-blue-700 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"${_scopeId}> Search </button></div></div><div class="flex space-x-3"${_scopeId}><div class=""${_scopeId}>`);
            _push2(ssrRenderComponent(unref(VSelect), {
              options: __props.developers,
              reduce: (developer2) => developer2,
              label: "name",
              class: "style-chooser w-64",
              modelValue: developer.value,
              "onUpdate:modelValue": ($event) => developer.value = $event
            }, null, _parent2, _scopeId));
            if (__props.errors.developer) {
              _push2(`<span class="text-lg text-red-600 font-semibold"${_scopeId}>${ssrInterpolate(__props.errors.developer)}</span>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><button type="button" class="rounded-md bg-blue-700 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"${_scopeId}> Search </button></div></div></div>`);
            if (__props.apps) {
              _push2(`<div${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400 border" style="${ssrRenderStyle({ "width": "100%" })}"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400 border"${_scopeId}><tr${_scopeId}><th scope="col" class="p-4" style="${ssrRenderStyle({ "width": "5%" })}"${_scopeId}> ID </th><th scope="col" class="p-4" style="${ssrRenderStyle({ "width": "10%" })}"${_scopeId}>`);
              if (!checkAll.value) {
                _push2(`<button type="button" class="rounded-md bg-blue-700 px-2 py-1 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"${_scopeId}> All Checked </button>`);
              } else {
                _push2(`<button type="button" class="rounded-md bg-blue-700 px-2 py-1 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"${_scopeId}> All Unchecked </button>`);
              }
              _push2(`<span class="text-base capitalize mt-1 block text-center"${_scopeId}>${ssrInterpolate(checkedApps.value.length ?? 0)} of ${ssrInterpolate(props.apps.length)}</span></th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "10%" })}"${_scopeId}> Icon </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "20%" })}"${_scopeId}> Title </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "10%" })}"${_scopeId}> Rating </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "20%" })}"${_scopeId}> App ID </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "10%" })}"${_scopeId}> Type </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "15%" })}"${_scopeId}><button type="button" class="rounded-md bg-blue-700 px-2 py-1 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"${_scopeId}> Save All </button></th></tr></thead><tbody${_scopeId}><!--[-->`);
              ssrRenderList(__props.apps, (app, index) => {
                _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><td class="p-4 text-lg font-semibold"${_scopeId}>${ssrInterpolate(index + 1)}</td><td class="p-4 text-lg font-semibold"${_scopeId}>`);
                _push2(ssrRenderComponent(_sfc_main$2, {
                  modelValue: app.checked,
                  "onUpdate:modelValue": ($event) => app.checked = $event,
                  checked: app.checked,
                  onChange: ($event) => checkedApp(app)
                }, null, _parent2, _scopeId));
                _push2(`</td><td class="p-4 text-lg font-semibold"${_scopeId}><img${ssrRenderAttr("src", app.icon)} alt="" width="70"${_scopeId}></td><td class="p-4 text-lg font-semibold"${_scopeId}><span${_scopeId}>${ssrInterpolate(app.title)}</span></td><td class="p-4 text-lg font-semibold"${_scopeId}><div class="flex space-x-3 items-center"${_scopeId}><span class="text-lg"${_scopeId}>${ssrInterpolate(app.rating)}</span>`);
                _push2(ssrRenderComponent(unref(vue3StarRatings), {
                  modelValue: app.rating,
                  "onUpdate:modelValue": ($event) => app.rating = $event,
                  disableClick: "false",
                  inactiveColor: "#cbd5e1"
                }, null, _parent2, _scopeId));
                _push2(`</div></td><td class="p-4 text-lg font-semibold"${_scopeId}><span class="text-xs"${_scopeId}>${ssrInterpolate(app.app_id)}</span></td><td class="px-2 py-2 capitalize"${_scopeId}>${ssrInterpolate(app.type)}</td><td class="px-2 py-2 space-x-5"${_scopeId}></td></tr>`);
              });
              _push2(`<!--]--></tbody></table></div>`);
            } else {
              _push2(`<div class="text-center text-4xl font-extrabold bg-gradient-to-t from-green-300 to-green-800 bg-clip-text text-transparent leading-normal"${_scopeId}> Data Not Found </div>`);
            }
            _push2(`</div></div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "bg-white shadow-sm sm:rounded-lg" }, [
                loading.value ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "fixed top-0 flex items-center justify-center h-screen z-40 opacity-60 inset-1 w-full bg-slate-900"
                }, [
                  createVNode(_component_ion_icon, {
                    name: "sync",
                    class: "absolute top-1/2 right-[40%] animate-spin text-9xl text-red-100 font-extrabold"
                  })
                ])) : createCommentVNode("", true),
                createVNode("div", { class: "p-6 text-gray-900" }, [
                  createVNode("div", {
                    id: "content",
                    class: ""
                  }, [
                    createVNode(_component_Header, { title: "main.app-list" }),
                    createVNode("div", { class: "relative shadow-md sm:rounded-lg mt-5" }, [
                      createVNode("div", { class: "flex items-center justify-between flex-wrap md:flex-row space-y-4 md:space-y-0 pb-4 bg-white dark:bg-gray-900" }, [
                        createVNode("div", { class: "flex space-x-3" }, [
                          createVNode("div", null, [
                            createVNode("div", { class: "relative" }, [
                              createVNode("div", { class: "absolute inset-y-0 rtl:inset-r-0 start-0 flex items-center ps-3 pointer-events-none" }, [
                                (openBlock(), createBlock("svg", {
                                  class: "w-4 h-4 text-gray-500 dark:text-gray-400",
                                  "aria-hidden": "true",
                                  xmlns: "http://www.w3.org/2000/svg",
                                  fill: "none",
                                  viewBox: "0 0 20 20"
                                }, [
                                  createVNode("path", {
                                    stroke: "currentColor",
                                    "stroke-linecap": "round",
                                    "stroke-linejoin": "round",
                                    "stroke-width": "2",
                                    d: "m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
                                  })
                                ]))
                              ]),
                              withDirectives(createVNode("input", {
                                "onUpdate:modelValue": ($event) => search.value = $event,
                                type: "text",
                                id: "table-search-users",
                                class: "block p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg w-80 bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
                                placeholder: "Search for App"
                              }, null, 8, ["onUpdate:modelValue"]), [
                                [vModelText, search.value]
                              ])
                            ])
                          ]),
                          createVNode("div", null, [
                            createVNode("button", {
                              type: "button",
                              onClick: withModifiers(filterApps, ["prevent"]),
                              class: "rounded-md bg-blue-700 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"
                            }, " Search ")
                          ])
                        ]),
                        createVNode("div", { class: "flex space-x-3" }, [
                          createVNode("div", { class: "" }, [
                            createVNode(unref(VSelect), {
                              options: __props.categories,
                              reduce: (category2) => category2,
                              label: "name",
                              class: "style-chooser w-64",
                              modelValue: category.value,
                              "onUpdate:modelValue": ($event) => category.value = $event
                            }, null, 8, ["options", "reduce", "modelValue", "onUpdate:modelValue"]),
                            __props.errors.type ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.type), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", null, [
                            createVNode("button", {
                              type: "button",
                              onClick: withModifiers(filterAppsByCategory, ["prevent"]),
                              class: "rounded-md bg-blue-700 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"
                            }, " Search ")
                          ])
                        ]),
                        createVNode("div", { class: "flex space-x-3" }, [
                          createVNode("div", { class: "" }, [
                            createVNode(unref(VSelect), {
                              options: __props.developers,
                              reduce: (developer2) => developer2,
                              label: "name",
                              class: "style-chooser w-64",
                              modelValue: developer.value,
                              "onUpdate:modelValue": ($event) => developer.value = $event
                            }, null, 8, ["options", "reduce", "modelValue", "onUpdate:modelValue"]),
                            __props.errors.developer ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.developer), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", null, [
                            createVNode("button", {
                              type: "button",
                              onClick: withModifiers(filterAppsByDeveloper, ["prevent"]),
                              class: "rounded-md bg-blue-700 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"
                            }, " Search ")
                          ])
                        ])
                      ]),
                      __props.apps ? (openBlock(), createBlock("div", { key: 0 }, [
                        createVNode("table", {
                          class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400 border",
                          style: { "width": "100%" }
                        }, [
                          createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400 border" }, [
                            createVNode("tr", null, [
                              createVNode("th", {
                                scope: "col",
                                class: "p-4",
                                style: { "width": "5%" }
                              }, " ID "),
                              createVNode("th", {
                                scope: "col",
                                class: "p-4",
                                style: { "width": "10%" }
                              }, [
                                !checkAll.value ? (openBlock(), createBlock("button", {
                                  key: 0,
                                  type: "button",
                                  onClick: checkedAll,
                                  class: "rounded-md bg-blue-700 px-2 py-1 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"
                                }, " All Checked ")) : (openBlock(), createBlock("button", {
                                  key: 1,
                                  type: "button",
                                  onClick: uncheckedAll,
                                  class: "rounded-md bg-blue-700 px-2 py-1 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"
                                }, " All Unchecked ")),
                                createVNode("span", { class: "text-base capitalize mt-1 block text-center" }, toDisplayString(checkedApps.value.length ?? 0) + " of " + toDisplayString(props.apps.length), 1)
                              ]),
                              createVNode("th", {
                                scope: "col",
                                class: "px-6 py-3",
                                style: { "width": "10%" }
                              }, " Icon "),
                              createVNode("th", {
                                scope: "col",
                                class: "px-6 py-3",
                                style: { "width": "20%" }
                              }, " Title "),
                              createVNode("th", {
                                scope: "col",
                                class: "px-6 py-3",
                                style: { "width": "10%" }
                              }, " Rating "),
                              createVNode("th", {
                                scope: "col",
                                class: "px-6 py-3",
                                style: { "width": "20%" }
                              }, " App ID "),
                              createVNode("th", {
                                scope: "col",
                                class: "px-6 py-3",
                                style: { "width": "10%" }
                              }, " Type "),
                              createVNode("th", {
                                scope: "col",
                                class: "px-6 py-3",
                                style: { "width": "15%" }
                              }, [
                                createVNode("button", {
                                  type: "button",
                                  onClick: saveAll,
                                  class: "rounded-md bg-blue-700 px-2 py-1 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"
                                }, " Save All ")
                              ])
                            ])
                          ]),
                          createVNode("tbody", null, [
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.apps, (app, index) => {
                              return openBlock(), createBlock("tr", {
                                class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                                key: index
                              }, [
                                createVNode("td", { class: "p-4 text-lg font-semibold" }, toDisplayString(index + 1), 1),
                                createVNode("td", { class: "p-4 text-lg font-semibold" }, [
                                  createVNode(_sfc_main$2, {
                                    modelValue: app.checked,
                                    "onUpdate:modelValue": ($event) => app.checked = $event,
                                    checked: app.checked,
                                    onChange: ($event) => checkedApp(app)
                                  }, null, 8, ["modelValue", "onUpdate:modelValue", "checked", "onChange"])
                                ]),
                                createVNode("td", { class: "p-4 text-lg font-semibold" }, [
                                  createVNode("img", {
                                    src: app.icon,
                                    alt: "",
                                    width: "70"
                                  }, null, 8, ["src"])
                                ]),
                                createVNode("td", { class: "p-4 text-lg font-semibold" }, [
                                  createVNode("span", null, toDisplayString(app.title), 1)
                                ]),
                                createVNode("td", { class: "p-4 text-lg font-semibold" }, [
                                  createVNode("div", { class: "flex space-x-3 items-center" }, [
                                    createVNode("span", { class: "text-lg" }, toDisplayString(app.rating), 1),
                                    createVNode(unref(vue3StarRatings), {
                                      modelValue: app.rating,
                                      "onUpdate:modelValue": ($event) => app.rating = $event,
                                      disableClick: "false",
                                      inactiveColor: "#cbd5e1"
                                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                  ])
                                ]),
                                createVNode("td", { class: "p-4 text-lg font-semibold" }, [
                                  createVNode("span", { class: "text-xs" }, toDisplayString(app.app_id), 1)
                                ]),
                                createVNode("td", { class: "px-2 py-2 capitalize" }, toDisplayString(app.type), 1),
                                createVNode("td", { class: "px-2 py-2 space-x-5" })
                              ]);
                            }), 128))
                          ])
                        ])
                      ])) : (openBlock(), createBlock("div", {
                        key: 1,
                        class: "text-center text-4xl font-extrabold bg-gradient-to-t from-green-300 to-green-800 bg-clip-text text-transparent leading-normal"
                      }, " Data Not Found "))
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Scrape/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
