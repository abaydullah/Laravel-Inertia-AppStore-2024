import { ref, reactive, computed, watch, resolveComponent, unref, withCtx, createVNode, createTextVNode, withModifiers, openBlock, createBlock, toDisplayString, createCommentVNode, withDirectives, vModelText, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderClass, ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrRenderStyle } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-DnYYwDfw.js";
import { useForm, Head, usePage, router } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Modal-_hjahxgY.js";
import { Switch } from "@headlessui/vue";
/* empty css                    */
import "vue-select";
import "./Pagination-CzMcH4PS.js";
import "lodash";
import { createUpload } from "@mux/upchunk";
import vue3StarRatings from "vue3-star-ratings";
import { _ as _sfc_main$3 } from "./TextInput-D7U8fbl4.js";
import "./ApplicationLogo-3H3I4iid.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./NavLink-CscBEwLF.js";
const _sfc_main = {
  __name: "View",
  __ssrInlineRender: true,
  props: {
    app: Object,
    status: Number,
    sort: String,
    search: String,
    type: Number,
    errors: Object
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      version: "",
      version_code: "",
      screen_dpi: "",
      sha1: "",
      sha256: "",
      md5: "",
      minimum_android: "",
      minimum_android_level: "",
      target_android: "",
      target_android_level: "",
      architecture: "",
      permissions: "",
      languages: "",
      signature: "",
      file: "",
      file_size: "",
      file_type: "",
      date: "",
      whats_new: ""
    });
    let editForm = useForm({
      id: "",
      version: "",
      version_code: "",
      screen_dpi: "",
      sha1: "",
      sha256: "",
      md5: "",
      minimum_android: "",
      minimum_android_level: "",
      target_android: "",
      target_android_level: "",
      architecture: "",
      permissions: "",
      languages: "",
      signature: "",
      file: "",
      file_size: "",
      file_type: "",
      date: "",
      whats_new: ""
    });
    const file = ref(null);
    const initialState = {
      file: null,
      uploader: null,
      progress: 0,
      uploading: false,
      error: null,
      success: ""
    };
    const state = reactive({
      ...initialState,
      formattedProgress: computed(() => Math.round(state.progress)),
      reset: () => {
        Object.assign(state, initialState);
      }
    });
    const uploadFile = () => {
      state.file = file.value.files[0];
      if (!state.file) {
        return;
      }
      state.uploader = createUpload({
        "endpoint": route("admin.apps.versions.store", props.app.id),
        "method": "post",
        "headers": {
          "X-CSRF-TOKEN": usePage().props.csrf_token
        },
        file: state.file,
        "chunkSize": 10 * 1024
      });
      state.uploader.on("attempt", () => {
        state.error = null;
        state.uploading = true;
      });
      state.uploader.on("progress", (p) => {
        state.progress = p.detail;
      });
      state.uploader.on("success", () => {
        state.reset();
        state.success = "App Uploaded Successfully";
        router.reload({
          only: ["app"],
          preserveScroll: true
        });
      });
      state.uploader.on("error", (error) => {
        state.uploading = false;
        state.error = error.detail.message;
      });
    };
    const fileUpdate = ref(null);
    const initialStateUpdate = {
      file: null,
      uploader: null,
      progress: 0,
      uploading: false,
      error: null,
      success: ""
    };
    const stateUpdate = reactive({
      ...initialStateUpdate,
      formattedProgress: computed(() => Math.round(stateUpdate.progress)),
      reset: () => {
        Object.assign(stateUpdate, initialStateUpdate);
      }
    });
    const versionById = (id) => {
      var _a;
      return editForm = (_a = props.app) == null ? void 0 : _a.versions.find((v) => v.id === id);
    };
    watch(() => editForm.file, (file2) => {
      let data = versionById(editForm.id);
      editForm = data;
    });
    const updateUploadFile = () => {
      stateUpdate.file = fileUpdate.value.files[0];
      if (!stateUpdate.file) {
        return;
      }
      stateUpdate.uploader = createUpload({
        "endpoint": route("admin.apps.versions.update", { app: props.app.id, version: editForm.id }),
        "headers": {
          "X-CSRF-TOKEN": usePage().props.csrf_token
        },
        file: stateUpdate.file,
        "chunkSize": 10 * 1024
      });
      stateUpdate.uploader.on("attempt", () => {
        stateUpdate.error = null;
        stateUpdate.uploading = true;
      });
      stateUpdate.uploader.on("progress", (p) => {
        stateUpdate.progress = p.detail;
      });
      stateUpdate.uploader.on("success", () => {
        stateUpdate.reset();
        stateUpdate.success = "App Uploaded Successfully";
        router.reload({
          only: ["app"],
          preserveScroll: true,
          preserveState: true,
          replace: true
        });
        versionById(editForm.id);
      });
      stateUpdate.uploader.on("error", (error) => {
        stateUpdate.reset();
        stateUpdate.uploading = false;
        stateUpdate.error = error.detail.message;
      });
    };
    const isShow = ref(false);
    const loading = ref(false);
    const openModal = () => {
      isShow.value = true;
    };
    const closeModal = () => {
      isShow.value = false;
    };
    const cancel = () => {
      state.uploader.abort();
      state.reset();
    };
    const isShowUpdate = ref(false);
    const openUpdateModal = (app) => {
      isShowUpdate.value = true;
      editForm = app;
    };
    const closeUpdateModal = () => {
      isShowUpdate.value = false;
    };
    const update = () => {
      editForm.post(route("admin.categories.update", editForm.id), {
        preserveScroll: true,
        onSuccess: () => {
          isShowUpdate.value = false;
        }
      });
    };
    const syncApp = (app) => {
      loading.value = true;
      router.post(route("admin.apps.sync"), { app }, {
        preserveState: true,
        preserveScroll: true,
        onSuccess: () => loading.value = false
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ion_icon = resolveComponent("ion-icon");
      const _component_Header = resolveComponent("Header");
      const _component_DialogTitle = resolveComponent("DialogTitle");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Apps" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-xl font-semibold leading-tight text-gray-800"${_scopeId}> Apps </h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-xl font-semibold leading-tight text-gray-800" }, " Apps ")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d, _e, _f, _g, _h;
          if (_push2) {
            _push2(`<div class="overflow-hidden bg-white shadow-sm sm:rounded-lg"${_scopeId}>`);
            if (loading.value) {
              _push2(`<div class="fixed top-0 flex items-center justify-center h-screen z-40 opacity-60 inset-1 w-full bg-slate-900"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_ion_icon, {
                name: "sync",
                class: "absolute top-1/2 right-[40%] animate-spin text-9xl text-red-100 font-extrabold"
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="p-6 text-gray-900"${_scopeId}><div id="content" class=""${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Header, { title: "main.app-list" }, null, _parent2, _scopeId));
            _push2(`<div class="relative overflow-x-auto shadow-md sm:rounded-lg mt-5"${_scopeId}><div class="flex items-center justify-between flex-column flex-wrap md:flex-row space-y-4 md:space-y-0 pb-4 bg-white dark:bg-gray-900"${_scopeId}>`);
            if (__props.app) {
              _push2(`<div${_scopeId}><div class="flex justify-between py-5"${_scopeId}><div class="mt-2 flex space-x-4 justify-items-center items-center"${_scopeId}><label for="name" class="text-lg font-semibold"${_scopeId}>Publish Status</label>`);
              _push2(ssrRenderComponent(unref(Switch), {
                modelValue: unref(form).status,
                "onUpdate:modelValue": ($event) => unref(form).status = $event,
                as: "template"
              }, {
                default: withCtx(({ checked }, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<button class="${ssrRenderClass([checked ? "bg-blue-600" : "bg-red-500", "relative inline-flex h-6 w-11 items-center rounded-full"])}"${_scopeId2}><span class="sr-only"${_scopeId2}>Enable</span><span class="${ssrRenderClass([checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"])}"${_scopeId2}></span></button>`);
                  } else {
                    return [
                      createVNode("button", {
                        class: ["relative inline-flex h-6 w-11 items-center rounded-full", checked ? "bg-blue-600" : "bg-red-500"]
                      }, [
                        createVNode("span", { class: "sr-only" }, "Enable"),
                        createVNode("span", {
                          class: [checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"]
                        }, null, 2)
                      ], 2)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              if (__props.errors.status) {
                _push2(`<span class="text-lg text-red-600 font-semibold"${_scopeId}>${ssrInterpolate(__props.errors.status)}</span>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-green-500 px-4 py-2 text-sm font-semibold hover:bg-green-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 text-white"${_scopeId}> Sync </button></div><div class="${ssrRenderClass([`bg-no-repeat bg-center bg-[url('${__props.app.cover_image_url}')]`, "mt-2 flex justify-between border space-x-3"])}"${_scopeId}><div class="flex space-x-3 bg-gray-50"${_scopeId}><div class="rounded-md"${_scopeId}><img${ssrRenderAttr("src", __props.app.icon)} alt="" width="240" class="object-cover rounded-sm shadow-md"${_scopeId}><div class="text-center capitalize text-3xl shadow-md bg-emerald-500 text-white"${_scopeId}>${ssrInterpolate(__props.app.type)}</div></div><div class="flex flex-col"${_scopeId}><span class="flex items-center"${_scopeId}><span class="text-lg"${_scopeId}>Title:</span><input type="text" class="px-2 py-0 rounded-md w-72 border-0"${ssrRenderAttr("value", __props.app.title)}${_scopeId}></span><span class="text-lg"${_scopeId}>App ID: ${ssrInterpolate(__props.app.app_id)}</span><span class="text-lg"${_scopeId}>Category: <a class="text-indigo-600 font-semibold"${ssrRenderAttr("href", (_a = __props.app.category) == null ? void 0 : _a.google_url)}${_scopeId}>${ssrInterpolate((_b = __props.app.category) == null ? void 0 : _b.name)}</a></span><span class="text-lg"${_scopeId}>Developer: <a class="text-indigo-600 font-semibold"${ssrRenderAttr("href", (_c = __props.app.developer) == null ? void 0 : _c.google_url)}${_scopeId}>${ssrInterpolate((_d = __props.app.developer) == null ? void 0 : _d.name)}</a></span><span${_scopeId}> Downloads: ${ssrInterpolate(__props.app.downloads)}</span><span${_scopeId}> Review: ${ssrInterpolate(__props.app.review)}</span><div class="flex space-x-3 items-center"${_scopeId}><span class="text-lg"${_scopeId}>Rating: ${ssrInterpolate(__props.app.rating)}</span>`);
              _push2(ssrRenderComponent(unref(vue3StarRatings), {
                modelValue: __props.app.rating,
                "onUpdate:modelValue": ($event) => __props.app.rating = $event,
                inactiveColor: "#cbd5e1"
              }, null, _parent2, _scopeId));
              _push2(`</div><span class="mt-5"${_scopeId}> Updated On: ${ssrInterpolate(__props.app.updated)}</span><span class="mt-5"${_scopeId}> Url : <a class="text-indigo-600 font-semibold" target="_blank"${ssrRenderAttr("href", __props.app.url)}${_scopeId}>Google Play</a></span></div></div>`);
              if (__props.app.trailer) {
                _push2(`<div${_scopeId}><iframe class="rounded-md shadow-md" width="400" height="280"${ssrRenderAttr("src", __props.app.trailer)}${_scopeId}></iframe></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
              if (__props.app.whats_new) {
                _push2(`<div${_scopeId}><h2 class="text-2xl font-semibold py-1 px-2 bg-emerald-50"${_scopeId}>What&#39;s New</h2><p class="p-5"${_scopeId}>${__props.app.whats_new ?? ""}</p></div>`);
              } else {
                _push2(`<!---->`);
              }
              if (__props.app.screenshots) {
                _push2(`<div class="border mt-5"${_scopeId}><h2 class="text-2xl font-semibold p-1 px-2 bg-emerald-500 text-white shadow-2xl rounded-sm"${_scopeId}> Screenshots</h2><div class="flex space-x-3 overflow-x-scroll bg-green-600"${_scopeId}><!--[-->`);
                ssrRenderList(__props.app.screenshots, (screenshot) => {
                  _push2(`<img${ssrRenderAttr("src", screenshot.photo)} alt="" width="180" class="shadow-2xl rounded-sm border m-2"${_scopeId}>`);
                });
                _push2(`<!--]--></div></div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`<div class="mt-2"${_scopeId}><h2 class="text-2xl font-semibold p-1 px-2 bg-emerald-500 text-white shadow-2xl rounded-sm"${_scopeId}> Description</h2><p class="text-sm p-2 border"${_scopeId}>${__props.app.description ?? ""}</p></div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div class="flex justify-between items-center mt-5"${_scopeId}><div class="w-11/12"${_scopeId}><h2 class="text-2xl font-semibold p-1 px-2 bg-emerald-50"${_scopeId}>Version</h2></div><div class="w-1/12"${_scopeId}><button type="button" class="rounded-md bg-blue-700 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"${_scopeId}> Add Version </button></div></div>`);
            if (__props.app.versions) {
              _push2(`<div${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400 border" style="${ssrRenderStyle({ "width": "100%" })}"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400 border"${_scopeId}><tr${_scopeId}><th scope="col" class="p-4" style="${ssrRenderStyle({ "width": "5%" })}"${_scopeId}> ID </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "10%" })}"${_scopeId}> Uploaded </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "20%" })}"${_scopeId}> Version </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "5%" })}"${_scopeId}> Size </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "5%" })}"${_scopeId}> Type </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "15%" })}"${_scopeId}> Minimum Required </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "15%" })}"${_scopeId}> Target </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "10%" })}"${_scopeId}> Status </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "20%" })}"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
              ssrRenderList(__props.app.versions, (app, index) => {
                _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><td class="p-4 text-lg font-semibold"${_scopeId}>${ssrInterpolate(index + 1)}</td><td class="p-4 text-lg font-semibold"${_scopeId}>${ssrInterpolate(app.date)}</td><th scope="row" class="p-2"${_scopeId}><div class="flex space-x-3"${_scopeId}> v${ssrInterpolate(app.version)} (${ssrInterpolate(app.version_code)}) </div></th><td class="px-2 py-2"${_scopeId}>${ssrInterpolate(app.file_size)}</td><td class="px-2 py-2"${_scopeId}>${ssrInterpolate(app.file_type)}</td><td class="px-2 py-2 capitalize"${_scopeId}>${ssrInterpolate(app.minimum_android)} (${ssrInterpolate(app.minimum_android_level)}) </td><td class="px-2 py-2 capitalize"${_scopeId}>${ssrInterpolate(app.target_android)} (${ssrInterpolate(app.target_android_level)}) </td><td class="px-2 py-2"${_scopeId}>`);
                if (app.status) {
                  _push2(`<span class="bg-green-600 text-white py-1 px-2 rounded-md font-normal"${_scopeId}>Published</span>`);
                } else {
                  _push2(`<span class="bg-red-600 text-white py-1 px-2 rounded-md font-normal"${_scopeId}>Unpublished</span>`);
                }
                _push2(`</td><td class="px-2 py-2 space-x-5"${_scopeId}><a href="#" class="font-medium dark:text-blue-500 hover:underline"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_ion_icon, {
                  name: "create",
                  class: "pt-2",
                  size: "large"
                }, null, _parent2, _scopeId));
                _push2(`</a><a href="#" class="font-medium text-blue-600 dark:text-blue-500 hover:underline"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_ion_icon, {
                  class: "pt-2 text-red-500",
                  name: "trash",
                  size: "large"
                }, null, _parent2, _scopeId));
                _push2(`</a></td></tr>`);
              });
              _push2(`<!--]--></tbody></table></div>`);
            } else {
              _push2(`<div class="text-center text-4xl font-extrabold bg-gradient-to-t from-green-300 to-green-800 bg-clip-text text-transparent leading-normal"${_scopeId}> Data Not Found </div>`);
            }
            _push2(`</div>`);
            _push2(ssrRenderComponent(_sfc_main$2, { show: isShow.value }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="px-10 pb-10 my-10"${_scopeId2}><div class="flex justify-between justify-items-center items-center py-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_DialogTitle, {
                    as: "h3",
                    class: "text-lg font-medium leading-6 text-gray-900"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Add New Version `);
                      } else {
                        return [
                          createTextVNode(" Add New Version ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div${_scopeId2}><button type="button" class="text-5xl leading-6 text-gray-400 font-normal" data-bs-dismiss="modal" aria-label="Close"${_scopeId2}> × </button></div></div><hr${_scopeId2}><form${_scopeId2}><div class="flex w-full items-center space-x-3"${_scopeId2}><div class="mt-2 w-10/12"${_scopeId2}><label for="file" class="text-lg font-semibold sr-only"${_scopeId2}>Apk File</label><input type="file" class="form-input px-4 py-3 rounded-md w-full my-2" name="file" placeholder="Enter Your App ID"${_scopeId2}>`);
                  if (__props.errors.file) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.file)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class=""${_scopeId2}><button type="submit" class="inline-flex justify-center rounded-md border border-transparent bg-blue-500 px-4 py-2 text-sm font-semibold hover:bg-blue-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 text-white"${_scopeId2}> Upload </button></div></div></form>`);
                  if (state.uploading) {
                    _push3(`<div${_scopeId2}><div class="bg-gray-200 h-4 overflow-hidden rounded"${_scopeId2}><div class="bg-blue-700 h-full transition-all duration-200" style="${ssrRenderStyle({ width: state.progress + "%" })}"${_scopeId2}></div></div><div class="flex justify-between items-center"${_scopeId2}><div class="flex items-center space-x-3"${_scopeId2}><button class="text-sm text-indigo-500"${_scopeId2}>Cancel</button>`);
                    if (!state.uploader.paused) {
                      _push3(`<button class="text-sm text-indigo-500"${_scopeId2}>Pause</button>`);
                    } else {
                      _push3(`<button class="text-sm text-indigo-500"${_scopeId2}>Resume</button>`);
                    }
                    _push3(`</div><div${_scopeId2}>${ssrInterpolate(state.formattedProgress)}%</div></div></div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  if (state.error) {
                    _push3(`<div${_scopeId2}><span class="text-red-400 font-semibold text-lg"${_scopeId2}>${ssrInterpolate(state.error)}</span></div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  if (state.success) {
                    _push3(`<div${_scopeId2}><span class="text-green-400 font-semibold text-lg"${_scopeId2}>${ssrInterpolate(state.success)}</span></div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "px-10 pb-10 my-10" }, [
                      createVNode("div", { class: "flex justify-between justify-items-center items-center py-2" }, [
                        createVNode(_component_DialogTitle, {
                          as: "h3",
                          class: "text-lg font-medium leading-6 text-gray-900"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Add New Version ")
                          ]),
                          _: 1
                        }),
                        createVNode("div", null, [
                          createVNode("button", {
                            type: "button",
                            class: "text-5xl leading-6 text-gray-400 font-normal",
                            onClick: closeModal,
                            "data-bs-dismiss": "modal",
                            "aria-label": "Close"
                          }, " × ")
                        ])
                      ]),
                      createVNode("hr"),
                      createVNode("form", {
                        onSubmit: withModifiers(uploadFile, ["prevent"])
                      }, [
                        createVNode("div", { class: "flex w-full items-center space-x-3" }, [
                          createVNode("div", { class: "mt-2 w-10/12" }, [
                            createVNode("label", {
                              for: "file",
                              class: "text-lg font-semibold sr-only"
                            }, "Apk File"),
                            createVNode("input", {
                              type: "file",
                              class: "form-input px-4 py-3 rounded-md w-full my-2",
                              ref_key: "file",
                              ref: file,
                              name: "file",
                              placeholder: "Enter Your App ID"
                            }, null, 512),
                            __props.errors.file ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.file), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "" }, [
                            createVNode("button", {
                              type: "submit",
                              class: "inline-flex justify-center rounded-md border border-transparent bg-blue-500 px-4 py-2 text-sm font-semibold hover:bg-blue-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 text-white"
                            }, " Upload ")
                          ])
                        ])
                      ], 32),
                      state.uploading ? (openBlock(), createBlock("div", { key: 0 }, [
                        createVNode("div", { class: "bg-gray-200 h-4 overflow-hidden rounded" }, [
                          createVNode("div", {
                            class: "bg-blue-700 h-full transition-all duration-200",
                            style: { width: state.progress + "%" }
                          }, null, 4)
                        ]),
                        createVNode("div", { class: "flex justify-between items-center" }, [
                          createVNode("div", { class: "flex items-center space-x-3" }, [
                            createVNode("button", {
                              class: "text-sm text-indigo-500",
                              onClick: cancel
                            }, "Cancel"),
                            !state.uploader.paused ? (openBlock(), createBlock("button", {
                              key: 0,
                              class: "text-sm text-indigo-500",
                              onClick: ($event) => state.uploader.pause()
                            }, "Pause", 8, ["onClick"])) : (openBlock(), createBlock("button", {
                              key: 1,
                              class: "text-sm text-indigo-500",
                              onClick: ($event) => state.uploader.resume()
                            }, "Resume", 8, ["onClick"]))
                          ]),
                          createVNode("div", null, toDisplayString(state.formattedProgress) + "%", 1)
                        ])
                      ])) : createCommentVNode("", true),
                      state.error ? (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode("span", { class: "text-red-400 font-semibold text-lg" }, toDisplayString(state.error), 1)
                      ])) : createCommentVNode("", true),
                      state.success ? (openBlock(), createBlock("div", { key: 2 }, [
                        createVNode("span", { class: "text-green-400 font-semibold text-lg" }, toDisplayString(state.success), 1)
                      ])) : createCommentVNode("", true)
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, { show: isShowUpdate.value }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-10 my-10"${_scopeId2}><div class="flex justify-between justify-items-center items-center py-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_DialogTitle, {
                    as: "h3",
                    class: "text-lg font-medium leading-6 text-gray-900"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Edit APK `);
                      } else {
                        return [
                          createTextVNode(" Edit APK ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div${_scopeId2}><button type="button" class="text-5xl leading-6 text-gray-400 font-normal" data-bs-dismiss="modal" aria-label="Close"${_scopeId2}> × </button></div></div><hr${_scopeId2}><form${_scopeId2}><div class="flex w-full items-center space-x-3"${_scopeId2}><div class="mt-2 w-10/12"${_scopeId2}><label for="fileUpdate" class="text-lg font-semibold sr-only"${_scopeId2}>Apk File</label><input type="file" class="form-input px-4 py-3 rounded-md w-full my-2" name="fileUpdate"${_scopeId2}>`);
                  if (__props.errors.fileUpdate) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.fileUpdate)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class=""${_scopeId2}><button type="submit" class="inline-flex justify-center rounded-md border border-transparent bg-blue-500 px-4 py-2 text-sm font-semibold hover:bg-blue-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 text-white"${_scopeId2}> Upload </button></div></div></form>`);
                  if (stateUpdate.uploading) {
                    _push3(`<div${_scopeId2}><div class="bg-gray-200 h-4 overflow-hidden rounded"${_scopeId2}><div class="bg-blue-700 h-full transition-all duration-200" style="${ssrRenderStyle({ width: stateUpdate.progress + "%" })}"${_scopeId2}></div></div><div class="flex justify-between items-center"${_scopeId2}><div class="flex items-center space-x-3"${_scopeId2}><button class="text-sm text-indigo-500"${_scopeId2}>Cancel</button>`);
                    if (!stateUpdate.uploader.paused) {
                      _push3(`<button class="text-sm text-indigo-500"${_scopeId2}>Pause</button>`);
                    } else {
                      _push3(`<button class="text-sm text-indigo-500"${_scopeId2}>Resume</button>`);
                    }
                    _push3(`</div><div${_scopeId2}>${ssrInterpolate(stateUpdate.formattedProgress)}%</div></div></div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`<div class="grid grid-cols-2"${_scopeId2}><div class="mt-2"${_scopeId2}><label for="version" class="text-lg font-semibold"${_scopeId2}>Version</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="version"${ssrRenderAttr("value", unref(editForm).version)} placeholder="Enter Your Version"${_scopeId2}>`);
                  if (__props.errors.version) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.version)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="version_code" class="text-lg font-semibold"${_scopeId2}>Version Code</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="version_code"${ssrRenderAttr("value", unref(editForm).version_code)} placeholder="Enter Your Version Code"${_scopeId2}>`);
                  if (__props.errors.version_code) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.version_code)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="minimum_android" class="text-lg font-semibold"${_scopeId2}>Minimum Android</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="minimum_android"${ssrRenderAttr("value", unref(editForm).minimum_android)} placeholder="Enter Your Minimum Android"${_scopeId2}>`);
                  if (__props.errors.minimum_android) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.minimum_android)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="target_android" class="text-lg font-semibold"${_scopeId2}>Target Android</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="target_android"${ssrRenderAttr("value", unref(editForm).target_android)} placeholder="Enter Your Target Android"${_scopeId2}>`);
                  if (__props.errors.target_android) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.target_android)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div> <div class="mt-2"${_scopeId2}><label for="minimum_android_level" class="text-lg font-semibold"${_scopeId2}>Minimum Android Level</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="minimum_android_level"${ssrRenderAttr("value", unref(editForm).minimum_android_level)} placeholder="Enter Your Minimum Android Level"${_scopeId2}>`);
                  if (__props.errors.minimum_android_level) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.minimum_android_level)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="target_android_level" class="text-lg font-semibold"${_scopeId2}>Target Android Level</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="target_android_level"${ssrRenderAttr("value", unref(editForm).target_android_level)} placeholder="Enter Your Target Android Level"${_scopeId2}>`);
                  if (__props.errors.target_android_level) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.target_android_level)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="architecture" class="text-lg font-semibold"${_scopeId2}>Architecture</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="architecture"${ssrRenderAttr("value", unref(editForm).architecture)} placeholder="Enter Your Architecture"${_scopeId2}>`);
                  if (__props.errors.architecture) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.architecture)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="screen_dpi" class="text-lg font-semibold"${_scopeId2}>Screen DPI</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="screen_dpi"${ssrRenderAttr("value", unref(editForm).screen_dpi)} placeholder="Enter Your Screen DPI"${_scopeId2}>`);
                  if (__props.errors.screen_dpi) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.screen_dpi)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="languages" class="text-lg font-semibold"${_scopeId2}>Languages</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="languages"${ssrRenderAttr("value", unref(editForm).languages)} placeholder="Enter Your Languages"${_scopeId2}>`);
                  if (__props.errors.languages) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.languages)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="date" class="text-lg font-semibold"${_scopeId2}>Date</label><input type="date" class="form-input px-4 py-3 rounded-md w-full my-2" id="date"${ssrRenderAttr("value", unref(editForm).date)}${_scopeId2}>`);
                  if (__props.errors.date) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.date)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div></div><div class="mt-2"${_scopeId2}><label for="date" class="text-lg font-semibold"${_scopeId2}>What&#39;s New</label>`);
                  _push3(ssrRenderComponent(_sfc_main$3, {
                    modelValue: unref(form).whats_new,
                    "onUpdate:modelValue": ($event) => unref(form).whats_new = $event
                  }, null, _parent3, _scopeId2));
                  _push3(`</div><div class="mt-2 flex space-x-4 justify-items-center items-center"${_scopeId2}><label for="name" class="text-lg font-semibold"${_scopeId2}>Publish Status</label>`);
                  _push3(ssrRenderComponent(unref(Switch), {
                    modelValue: unref(editForm).status,
                    "onUpdate:modelValue": ($event) => unref(editForm).status = $event,
                    as: "template"
                  }, {
                    default: withCtx(({ checked }, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<button class="${ssrRenderClass([checked ? "bg-blue-600" : "bg-red-500", "relative inline-flex h-6 w-11 items-center rounded-full"])}"${_scopeId3}><span class="sr-only"${_scopeId3}>Enable</span><span class="${ssrRenderClass([checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"])}"${_scopeId3}></span></button>`);
                      } else {
                        return [
                          createVNode("button", {
                            class: ["relative inline-flex h-6 w-11 items-center rounded-full", checked ? "bg-blue-600" : "bg-red-500"]
                          }, [
                            createVNode("span", { class: "sr-only" }, "Enable"),
                            createVNode("span", {
                              class: [checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"]
                            }, null, 2)
                          ], 2)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  if (__props.errors.status) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.status)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-4 float-end space-x-2"${_scopeId2}><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"${_scopeId2}> Submit </button><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"${_scopeId2}>Cancel </button></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-10 my-10" }, [
                      createVNode("div", { class: "flex justify-between justify-items-center items-center py-2" }, [
                        createVNode(_component_DialogTitle, {
                          as: "h3",
                          class: "text-lg font-medium leading-6 text-gray-900"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Edit APK ")
                          ]),
                          _: 1
                        }),
                        createVNode("div", null, [
                          createVNode("button", {
                            type: "button",
                            class: "text-5xl leading-6 text-gray-400 font-normal",
                            onClick: closeUpdateModal,
                            "data-bs-dismiss": "modal",
                            "aria-label": "Close"
                          }, " × ")
                        ])
                      ]),
                      createVNode("hr"),
                      createVNode("form", {
                        onSubmit: withModifiers(updateUploadFile, ["prevent"])
                      }, [
                        createVNode("div", { class: "flex w-full items-center space-x-3" }, [
                          createVNode("div", { class: "mt-2 w-10/12" }, [
                            createVNode("label", {
                              for: "fileUpdate",
                              class: "text-lg font-semibold sr-only"
                            }, "Apk File"),
                            createVNode("input", {
                              type: "file",
                              class: "form-input px-4 py-3 rounded-md w-full my-2",
                              ref_key: "fileUpdate",
                              ref: fileUpdate,
                              name: "fileUpdate"
                            }, null, 512),
                            __props.errors.fileUpdate ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.fileUpdate), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "" }, [
                            createVNode("button", {
                              type: "submit",
                              class: "inline-flex justify-center rounded-md border border-transparent bg-blue-500 px-4 py-2 text-sm font-semibold hover:bg-blue-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 text-white"
                            }, " Upload ")
                          ])
                        ])
                      ], 32),
                      stateUpdate.uploading ? (openBlock(), createBlock("div", { key: 0 }, [
                        createVNode("div", { class: "bg-gray-200 h-4 overflow-hidden rounded" }, [
                          createVNode("div", {
                            class: "bg-blue-700 h-full transition-all duration-200",
                            style: { width: stateUpdate.progress + "%" }
                          }, null, 4)
                        ]),
                        createVNode("div", { class: "flex justify-between items-center" }, [
                          createVNode("div", { class: "flex items-center space-x-3" }, [
                            createVNode("button", {
                              class: "text-sm text-indigo-500",
                              onClick: cancel
                            }, "Cancel"),
                            !stateUpdate.uploader.paused ? (openBlock(), createBlock("button", {
                              key: 0,
                              class: "text-sm text-indigo-500",
                              onClick: ($event) => stateUpdate.uploader.pause()
                            }, "Pause", 8, ["onClick"])) : (openBlock(), createBlock("button", {
                              key: 1,
                              class: "text-sm text-indigo-500",
                              onClick: ($event) => stateUpdate.uploader.resume()
                            }, "Resume", 8, ["onClick"]))
                          ]),
                          createVNode("div", null, toDisplayString(stateUpdate.formattedProgress) + "%", 1)
                        ])
                      ])) : createCommentVNode("", true),
                      createVNode("div", { class: "grid grid-cols-2" }, [
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "version",
                            class: "text-lg font-semibold"
                          }, "Version"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "version",
                            "onUpdate:modelValue": ($event) => unref(editForm).version = $event,
                            placeholder: "Enter Your Version"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).version]
                          ]),
                          __props.errors.version ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.version), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "version_code",
                            class: "text-lg font-semibold"
                          }, "Version Code"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "version_code",
                            "onUpdate:modelValue": ($event) => unref(editForm).version_code = $event,
                            placeholder: "Enter Your Version Code"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).version_code]
                          ]),
                          __props.errors.version_code ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.version_code), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "minimum_android",
                            class: "text-lg font-semibold"
                          }, "Minimum Android"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "minimum_android",
                            "onUpdate:modelValue": ($event) => unref(editForm).minimum_android = $event,
                            placeholder: "Enter Your Minimum Android"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).minimum_android]
                          ]),
                          __props.errors.minimum_android ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.minimum_android), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "target_android",
                            class: "text-lg font-semibold"
                          }, "Target Android"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "target_android",
                            "onUpdate:modelValue": ($event) => unref(editForm).target_android = $event,
                            placeholder: "Enter Your Target Android"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).target_android]
                          ]),
                          __props.errors.target_android ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.target_android), 1)) : createCommentVNode("", true)
                        ]),
                        createTextVNode(),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "minimum_android_level",
                            class: "text-lg font-semibold"
                          }, "Minimum Android Level"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "minimum_android_level",
                            "onUpdate:modelValue": ($event) => unref(editForm).minimum_android_level = $event,
                            placeholder: "Enter Your Minimum Android Level"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).minimum_android_level]
                          ]),
                          __props.errors.minimum_android_level ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.minimum_android_level), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "target_android_level",
                            class: "text-lg font-semibold"
                          }, "Target Android Level"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "target_android_level",
                            "onUpdate:modelValue": ($event) => unref(editForm).target_android_level = $event,
                            placeholder: "Enter Your Target Android Level"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).target_android_level]
                          ]),
                          __props.errors.target_android_level ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.target_android_level), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "architecture",
                            class: "text-lg font-semibold"
                          }, "Architecture"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "architecture",
                            "onUpdate:modelValue": ($event) => unref(editForm).architecture = $event,
                            placeholder: "Enter Your Architecture"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).architecture]
                          ]),
                          __props.errors.architecture ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.architecture), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "screen_dpi",
                            class: "text-lg font-semibold"
                          }, "Screen DPI"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "screen_dpi",
                            "onUpdate:modelValue": ($event) => unref(editForm).screen_dpi = $event,
                            placeholder: "Enter Your Screen DPI"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).screen_dpi]
                          ]),
                          __props.errors.screen_dpi ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.screen_dpi), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "languages",
                            class: "text-lg font-semibold"
                          }, "Languages"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "languages",
                            "onUpdate:modelValue": ($event) => unref(editForm).languages = $event,
                            placeholder: "Enter Your Languages"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).languages]
                          ]),
                          __props.errors.languages ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.languages), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "date",
                            class: "text-lg font-semibold"
                          }, "Date"),
                          withDirectives(createVNode("input", {
                            type: "date",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "date",
                            "onUpdate:modelValue": ($event) => unref(editForm).date = $event
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).date]
                          ]),
                          __props.errors.date ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.date), 1)) : createCommentVNode("", true)
                        ])
                      ]),
                      createVNode("div", { class: "mt-2" }, [
                        createVNode("label", {
                          for: "date",
                          class: "text-lg font-semibold"
                        }, "What's New"),
                        createVNode(_sfc_main$3, {
                          modelValue: unref(form).whats_new,
                          "onUpdate:modelValue": ($event) => unref(form).whats_new = $event
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("div", { class: "mt-2 flex space-x-4 justify-items-center items-center" }, [
                        createVNode("label", {
                          for: "name",
                          class: "text-lg font-semibold"
                        }, "Publish Status"),
                        createVNode(unref(Switch), {
                          modelValue: unref(editForm).status,
                          "onUpdate:modelValue": ($event) => unref(editForm).status = $event,
                          as: "template"
                        }, {
                          default: withCtx(({ checked }) => [
                            createVNode("button", {
                              class: ["relative inline-flex h-6 w-11 items-center rounded-full", checked ? "bg-blue-600" : "bg-red-500"]
                            }, [
                              createVNode("span", { class: "sr-only" }, "Enable"),
                              createVNode("span", {
                                class: [checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"]
                              }, null, 2)
                            ], 2)
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"]),
                        __props.errors.status ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.status), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-4 float-end space-x-2" }, [
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                          onClick: update
                        }, " Submit "),
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                          onClick: closeUpdateModal
                        }, "Cancel ")
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, { show: _ctx.isShowDelete }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="pb-10 m-10 border-x border-t rounded-md"${_scopeId2}><div class="flex justify-between justify-items-center items-center p-1 mb-2 rounded-md"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_DialogTitle, {
                    as: "h3",
                    class: "text-lg font-medium leading-6 text-gray-900"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Delete App `);
                      } else {
                        return [
                          createTextVNode(" Delete App ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div${_scopeId2}><button type="button" class="text-5xl leading-6 text-gray-400 font-normal" data-bs-dismiss="modal" aria-label="Close"${_scopeId2}> × </button></div></div><hr${_scopeId2}><div class="bg-red-100 p-5 text-red-700 space-y-2 rounded-md"${_scopeId2}><h2 class="flex space-x-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_ion_icon, {
                    name: "alert-circle-outline",
                    class: "text-3xl"
                  }, null, _parent3, _scopeId2));
                  _push3(`<span class="text-2xl"${_scopeId2}>Delete App</span></h2><p class="px-10"${_scopeId2}>You are sure you want to delete it?</p></div><div class="mt-4 space-x-2 float-end"${_scopeId2}><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"${_scopeId2}> Delete </button><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"${_scopeId2}>Cancel </button></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "pb-10 m-10 border-x border-t rounded-md" }, [
                      createVNode("div", { class: "flex justify-between justify-items-center items-center p-1 mb-2 rounded-md" }, [
                        createVNode(_component_DialogTitle, {
                          as: "h3",
                          class: "text-lg font-medium leading-6 text-gray-900"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Delete App ")
                          ]),
                          _: 1
                        }),
                        createVNode("div", null, [
                          createVNode("button", {
                            type: "button",
                            class: "text-5xl leading-6 text-gray-400 font-normal",
                            onClick: _ctx.closeDeleteModal,
                            "data-bs-dismiss": "modal",
                            "aria-label": "Close"
                          }, " × ", 8, ["onClick"])
                        ])
                      ]),
                      createVNode("hr"),
                      createVNode("div", { class: "bg-red-100 p-5 text-red-700 space-y-2 rounded-md" }, [
                        createVNode("h2", { class: "flex space-x-2" }, [
                          createVNode(_component_ion_icon, {
                            name: "alert-circle-outline",
                            class: "text-3xl"
                          }),
                          createVNode("span", { class: "text-2xl" }, "Delete App")
                        ]),
                        createVNode("p", { class: "px-10" }, "You are sure you want to delete it?")
                      ]),
                      createVNode("div", { class: "mt-4 space-x-2 float-end" }, [
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                          onClick: _ctx.deleteCategory
                        }, " Delete ", 8, ["onClick"]),
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                          onClick: _ctx.closeDeleteModal
                        }, "Cancel ", 8, ["onClick"])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg" }, [
                loading.value ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "fixed top-0 flex items-center justify-center h-screen z-40 opacity-60 inset-1 w-full bg-slate-900"
                }, [
                  createVNode(_component_ion_icon, {
                    name: "sync",
                    class: "absolute top-1/2 right-[40%] animate-spin text-9xl text-red-100 font-extrabold"
                  })
                ])) : createCommentVNode("", true),
                createVNode("div", { class: "p-6 text-gray-900" }, [
                  createVNode("div", {
                    id: "content",
                    class: ""
                  }, [
                    createVNode(_component_Header, { title: "main.app-list" }),
                    createVNode("div", { class: "relative overflow-x-auto shadow-md sm:rounded-lg mt-5" }, [
                      createVNode("div", { class: "flex items-center justify-between flex-column flex-wrap md:flex-row space-y-4 md:space-y-0 pb-4 bg-white dark:bg-gray-900" }, [
                        __props.app ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("div", { class: "flex justify-between py-5" }, [
                            createVNode("div", { class: "mt-2 flex space-x-4 justify-items-center items-center" }, [
                              createVNode("label", {
                                for: "name",
                                class: "text-lg font-semibold"
                              }, "Publish Status"),
                              createVNode(unref(Switch), {
                                modelValue: unref(form).status,
                                "onUpdate:modelValue": ($event) => unref(form).status = $event,
                                as: "template"
                              }, {
                                default: withCtx(({ checked }) => [
                                  createVNode("button", {
                                    class: ["relative inline-flex h-6 w-11 items-center rounded-full", checked ? "bg-blue-600" : "bg-red-500"]
                                  }, [
                                    createVNode("span", { class: "sr-only" }, "Enable"),
                                    createVNode("span", {
                                      class: [checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"]
                                    }, null, 2)
                                  ], 2)
                                ]),
                                _: 1
                              }, 8, ["modelValue", "onUpdate:modelValue"]),
                              __props.errors.status ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "text-lg text-red-600 font-semibold"
                              }, toDisplayString(__props.errors.status), 1)) : createCommentVNode("", true)
                            ]),
                            createVNode("button", {
                              type: "button",
                              class: "inline-flex justify-center rounded-md border border-transparent bg-green-500 px-4 py-2 text-sm font-semibold hover:bg-green-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 text-white",
                              onClick: ($event) => syncApp(__props.app)
                            }, " Sync ", 8, ["onClick"])
                          ]),
                          createVNode("div", {
                            class: ["mt-2 flex justify-between border space-x-3", `bg-no-repeat bg-center bg-[url('${__props.app.cover_image_url}')]`]
                          }, [
                            createVNode("div", { class: "flex space-x-3 bg-gray-50" }, [
                              createVNode("div", { class: "rounded-md" }, [
                                createVNode("img", {
                                  src: __props.app.icon,
                                  alt: "",
                                  width: "240",
                                  class: "object-cover rounded-sm shadow-md"
                                }, null, 8, ["src"]),
                                createVNode("div", { class: "text-center capitalize text-3xl shadow-md bg-emerald-500 text-white" }, toDisplayString(__props.app.type), 1)
                              ]),
                              createVNode("div", { class: "flex flex-col" }, [
                                createVNode("span", { class: "flex items-center" }, [
                                  createVNode("span", { class: "text-lg" }, "Title:"),
                                  withDirectives(createVNode("input", {
                                    type: "text",
                                    class: "px-2 py-0 rounded-md w-72 border-0",
                                    "onUpdate:modelValue": ($event) => __props.app.title = $event
                                  }, null, 8, ["onUpdate:modelValue"]), [
                                    [vModelText, __props.app.title]
                                  ])
                                ]),
                                createVNode("span", { class: "text-lg" }, "App ID: " + toDisplayString(__props.app.app_id), 1),
                                createVNode("span", { class: "text-lg" }, [
                                  createTextVNode("Category: "),
                                  createVNode("a", {
                                    class: "text-indigo-600 font-semibold",
                                    href: (_e = __props.app.category) == null ? void 0 : _e.google_url
                                  }, toDisplayString((_f = __props.app.category) == null ? void 0 : _f.name), 9, ["href"])
                                ]),
                                createVNode("span", { class: "text-lg" }, [
                                  createTextVNode("Developer: "),
                                  createVNode("a", {
                                    class: "text-indigo-600 font-semibold",
                                    href: (_g = __props.app.developer) == null ? void 0 : _g.google_url
                                  }, toDisplayString((_h = __props.app.developer) == null ? void 0 : _h.name), 9, ["href"])
                                ]),
                                createVNode("span", null, " Downloads: " + toDisplayString(__props.app.downloads), 1),
                                createVNode("span", null, " Review: " + toDisplayString(__props.app.review), 1),
                                createVNode("div", { class: "flex space-x-3 items-center" }, [
                                  createVNode("span", { class: "text-lg" }, "Rating: " + toDisplayString(__props.app.rating), 1),
                                  createVNode(unref(vue3StarRatings), {
                                    modelValue: __props.app.rating,
                                    "onUpdate:modelValue": ($event) => __props.app.rating = $event,
                                    inactiveColor: "#cbd5e1"
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ]),
                                createVNode("span", { class: "mt-5" }, " Updated On: " + toDisplayString(__props.app.updated), 1),
                                createVNode("span", { class: "mt-5" }, [
                                  createTextVNode(" Url : "),
                                  createVNode("a", {
                                    class: "text-indigo-600 font-semibold",
                                    target: "_blank",
                                    href: __props.app.url
                                  }, "Google Play", 8, ["href"])
                                ])
                              ])
                            ]),
                            __props.app.trailer ? (openBlock(), createBlock("div", { key: 0 }, [
                              createVNode("iframe", {
                                class: "rounded-md shadow-md",
                                width: "400",
                                height: "280",
                                src: __props.app.trailer
                              }, null, 8, ["src"])
                            ])) : createCommentVNode("", true)
                          ], 2),
                          __props.app.whats_new ? (openBlock(), createBlock("div", { key: 0 }, [
                            createVNode("h2", { class: "text-2xl font-semibold py-1 px-2 bg-emerald-50" }, "What's New"),
                            createVNode("p", {
                              innerHTML: __props.app.whats_new,
                              class: "p-5"
                            }, null, 8, ["innerHTML"])
                          ])) : createCommentVNode("", true),
                          __props.app.screenshots ? (openBlock(), createBlock("div", {
                            key: 1,
                            class: "border mt-5"
                          }, [
                            createVNode("h2", { class: "text-2xl font-semibold p-1 px-2 bg-emerald-500 text-white shadow-2xl rounded-sm" }, " Screenshots"),
                            createVNode("div", { class: "flex space-x-3 overflow-x-scroll bg-green-600" }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(__props.app.screenshots, (screenshot) => {
                                return openBlock(), createBlock("img", {
                                  src: screenshot.photo,
                                  alt: "",
                                  width: "180",
                                  class: "shadow-2xl rounded-sm border m-2"
                                }, null, 8, ["src"]);
                              }), 256))
                            ])
                          ])) : createCommentVNode("", true),
                          createVNode("div", { class: "mt-2" }, [
                            createVNode("h2", { class: "text-2xl font-semibold p-1 px-2 bg-emerald-500 text-white shadow-2xl rounded-sm" }, " Description"),
                            createVNode("p", {
                              innerHTML: __props.app.description,
                              class: "text-sm p-2 border"
                            }, null, 8, ["innerHTML"])
                          ])
                        ])) : createCommentVNode("", true)
                      ])
                    ]),
                    createVNode("div", { class: "flex justify-between items-center mt-5" }, [
                      createVNode("div", { class: "w-11/12" }, [
                        createVNode("h2", { class: "text-2xl font-semibold p-1 px-2 bg-emerald-50" }, "Version")
                      ]),
                      createVNode("div", { class: "w-1/12" }, [
                        createVNode("button", {
                          type: "button",
                          onClick: openModal,
                          class: "rounded-md bg-blue-700 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-white/75"
                        }, " Add Version ")
                      ])
                    ]),
                    __props.app.versions ? (openBlock(), createBlock("div", { key: 0 }, [
                      createVNode("table", {
                        class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400 border",
                        style: { "width": "100%" }
                      }, [
                        createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400 border" }, [
                          createVNode("tr", null, [
                            createVNode("th", {
                              scope: "col",
                              class: "p-4",
                              style: { "width": "5%" }
                            }, " ID "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3",
                              style: { "width": "10%" }
                            }, " Uploaded "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3",
                              style: { "width": "20%" }
                            }, " Version "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3",
                              style: { "width": "5%" }
                            }, " Size "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3",
                              style: { "width": "5%" }
                            }, " Type "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3",
                              style: { "width": "15%" }
                            }, " Minimum Required "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3",
                              style: { "width": "15%" }
                            }, " Target "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3",
                              style: { "width": "10%" }
                            }, " Status "),
                            createVNode("th", {
                              scope: "col",
                              class: "px-6 py-3",
                              style: { "width": "20%" }
                            }, " Action ")
                          ])
                        ]),
                        createVNode("tbody", null, [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.app.versions, (app, index) => {
                            return openBlock(), createBlock("tr", {
                              class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                              key: index
                            }, [
                              createVNode("td", { class: "p-4 text-lg font-semibold" }, toDisplayString(index + 1), 1),
                              createVNode("td", { class: "p-4 text-lg font-semibold" }, toDisplayString(app.date), 1),
                              createVNode("th", {
                                scope: "row",
                                class: "p-2"
                              }, [
                                createVNode("div", { class: "flex space-x-3" }, " v" + toDisplayString(app.version) + " (" + toDisplayString(app.version_code) + ") ", 1)
                              ]),
                              createVNode("td", { class: "px-2 py-2" }, toDisplayString(app.file_size), 1),
                              createVNode("td", { class: "px-2 py-2" }, toDisplayString(app.file_type), 1),
                              createVNode("td", { class: "px-2 py-2 capitalize" }, toDisplayString(app.minimum_android) + " (" + toDisplayString(app.minimum_android_level) + ") ", 1),
                              createVNode("td", { class: "px-2 py-2 capitalize" }, toDisplayString(app.target_android) + " (" + toDisplayString(app.target_android_level) + ") ", 1),
                              createVNode("td", { class: "px-2 py-2" }, [
                                app.status ? (openBlock(), createBlock("span", {
                                  key: 0,
                                  class: "bg-green-600 text-white py-1 px-2 rounded-md font-normal"
                                }, "Published")) : (openBlock(), createBlock("span", {
                                  key: 1,
                                  class: "bg-red-600 text-white py-1 px-2 rounded-md font-normal"
                                }, "Unpublished"))
                              ]),
                              createVNode("td", { class: "px-2 py-2 space-x-5" }, [
                                createVNode("a", {
                                  href: "#",
                                  class: "font-medium dark:text-blue-500 hover:underline",
                                  onClick: ($event) => openUpdateModal(app)
                                }, [
                                  createVNode(_component_ion_icon, {
                                    name: "create",
                                    class: "pt-2",
                                    size: "large"
                                  })
                                ], 8, ["onClick"]),
                                createVNode("a", {
                                  href: "#",
                                  class: "font-medium text-blue-600 dark:text-blue-500 hover:underline",
                                  onClick: ($event) => _ctx.openDeleteModal(app)
                                }, [
                                  createVNode(_component_ion_icon, {
                                    class: "pt-2 text-red-500",
                                    name: "trash",
                                    size: "large"
                                  })
                                ], 8, ["onClick"])
                              ])
                            ]);
                          }), 128))
                        ])
                      ])
                    ])) : (openBlock(), createBlock("div", {
                      key: 1,
                      class: "text-center text-4xl font-extrabold bg-gradient-to-t from-green-300 to-green-800 bg-clip-text text-transparent leading-normal"
                    }, " Data Not Found "))
                  ]),
                  createVNode(_sfc_main$2, { show: isShow.value }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "px-10 pb-10 my-10" }, [
                        createVNode("div", { class: "flex justify-between justify-items-center items-center py-2" }, [
                          createVNode(_component_DialogTitle, {
                            as: "h3",
                            class: "text-lg font-medium leading-6 text-gray-900"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Add New Version ")
                            ]),
                            _: 1
                          }),
                          createVNode("div", null, [
                            createVNode("button", {
                              type: "button",
                              class: "text-5xl leading-6 text-gray-400 font-normal",
                              onClick: closeModal,
                              "data-bs-dismiss": "modal",
                              "aria-label": "Close"
                            }, " × ")
                          ])
                        ]),
                        createVNode("hr"),
                        createVNode("form", {
                          onSubmit: withModifiers(uploadFile, ["prevent"])
                        }, [
                          createVNode("div", { class: "flex w-full items-center space-x-3" }, [
                            createVNode("div", { class: "mt-2 w-10/12" }, [
                              createVNode("label", {
                                for: "file",
                                class: "text-lg font-semibold sr-only"
                              }, "Apk File"),
                              createVNode("input", {
                                type: "file",
                                class: "form-input px-4 py-3 rounded-md w-full my-2",
                                ref_key: "file",
                                ref: file,
                                name: "file",
                                placeholder: "Enter Your App ID"
                              }, null, 512),
                              __props.errors.file ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "text-lg text-red-600 font-semibold"
                              }, toDisplayString(__props.errors.file), 1)) : createCommentVNode("", true)
                            ]),
                            createVNode("div", { class: "" }, [
                              createVNode("button", {
                                type: "submit",
                                class: "inline-flex justify-center rounded-md border border-transparent bg-blue-500 px-4 py-2 text-sm font-semibold hover:bg-blue-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 text-white"
                              }, " Upload ")
                            ])
                          ])
                        ], 32),
                        state.uploading ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("div", { class: "bg-gray-200 h-4 overflow-hidden rounded" }, [
                            createVNode("div", {
                              class: "bg-blue-700 h-full transition-all duration-200",
                              style: { width: state.progress + "%" }
                            }, null, 4)
                          ]),
                          createVNode("div", { class: "flex justify-between items-center" }, [
                            createVNode("div", { class: "flex items-center space-x-3" }, [
                              createVNode("button", {
                                class: "text-sm text-indigo-500",
                                onClick: cancel
                              }, "Cancel"),
                              !state.uploader.paused ? (openBlock(), createBlock("button", {
                                key: 0,
                                class: "text-sm text-indigo-500",
                                onClick: ($event) => state.uploader.pause()
                              }, "Pause", 8, ["onClick"])) : (openBlock(), createBlock("button", {
                                key: 1,
                                class: "text-sm text-indigo-500",
                                onClick: ($event) => state.uploader.resume()
                              }, "Resume", 8, ["onClick"]))
                            ]),
                            createVNode("div", null, toDisplayString(state.formattedProgress) + "%", 1)
                          ])
                        ])) : createCommentVNode("", true),
                        state.error ? (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode("span", { class: "text-red-400 font-semibold text-lg" }, toDisplayString(state.error), 1)
                        ])) : createCommentVNode("", true),
                        state.success ? (openBlock(), createBlock("div", { key: 2 }, [
                          createVNode("span", { class: "text-green-400 font-semibold text-lg" }, toDisplayString(state.success), 1)
                        ])) : createCommentVNode("", true)
                      ])
                    ]),
                    _: 1
                  }, 8, ["show"]),
                  createVNode(_sfc_main$2, { show: isShowUpdate.value }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "p-10 my-10" }, [
                        createVNode("div", { class: "flex justify-between justify-items-center items-center py-2" }, [
                          createVNode(_component_DialogTitle, {
                            as: "h3",
                            class: "text-lg font-medium leading-6 text-gray-900"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Edit APK ")
                            ]),
                            _: 1
                          }),
                          createVNode("div", null, [
                            createVNode("button", {
                              type: "button",
                              class: "text-5xl leading-6 text-gray-400 font-normal",
                              onClick: closeUpdateModal,
                              "data-bs-dismiss": "modal",
                              "aria-label": "Close"
                            }, " × ")
                          ])
                        ]),
                        createVNode("hr"),
                        createVNode("form", {
                          onSubmit: withModifiers(updateUploadFile, ["prevent"])
                        }, [
                          createVNode("div", { class: "flex w-full items-center space-x-3" }, [
                            createVNode("div", { class: "mt-2 w-10/12" }, [
                              createVNode("label", {
                                for: "fileUpdate",
                                class: "text-lg font-semibold sr-only"
                              }, "Apk File"),
                              createVNode("input", {
                                type: "file",
                                class: "form-input px-4 py-3 rounded-md w-full my-2",
                                ref_key: "fileUpdate",
                                ref: fileUpdate,
                                name: "fileUpdate"
                              }, null, 512),
                              __props.errors.fileUpdate ? (openBlock(), createBlock("span", {
                                key: 0,
                                class: "text-lg text-red-600 font-semibold"
                              }, toDisplayString(__props.errors.fileUpdate), 1)) : createCommentVNode("", true)
                            ]),
                            createVNode("div", { class: "" }, [
                              createVNode("button", {
                                type: "submit",
                                class: "inline-flex justify-center rounded-md border border-transparent bg-blue-500 px-4 py-2 text-sm font-semibold hover:bg-blue-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 text-white"
                              }, " Upload ")
                            ])
                          ])
                        ], 32),
                        stateUpdate.uploading ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("div", { class: "bg-gray-200 h-4 overflow-hidden rounded" }, [
                            createVNode("div", {
                              class: "bg-blue-700 h-full transition-all duration-200",
                              style: { width: stateUpdate.progress + "%" }
                            }, null, 4)
                          ]),
                          createVNode("div", { class: "flex justify-between items-center" }, [
                            createVNode("div", { class: "flex items-center space-x-3" }, [
                              createVNode("button", {
                                class: "text-sm text-indigo-500",
                                onClick: cancel
                              }, "Cancel"),
                              !stateUpdate.uploader.paused ? (openBlock(), createBlock("button", {
                                key: 0,
                                class: "text-sm text-indigo-500",
                                onClick: ($event) => stateUpdate.uploader.pause()
                              }, "Pause", 8, ["onClick"])) : (openBlock(), createBlock("button", {
                                key: 1,
                                class: "text-sm text-indigo-500",
                                onClick: ($event) => stateUpdate.uploader.resume()
                              }, "Resume", 8, ["onClick"]))
                            ]),
                            createVNode("div", null, toDisplayString(stateUpdate.formattedProgress) + "%", 1)
                          ])
                        ])) : createCommentVNode("", true),
                        createVNode("div", { class: "grid grid-cols-2" }, [
                          createVNode("div", { class: "mt-2" }, [
                            createVNode("label", {
                              for: "version",
                              class: "text-lg font-semibold"
                            }, "Version"),
                            withDirectives(createVNode("input", {
                              type: "text",
                              class: "form-input px-4 py-3 rounded-md w-full my-2",
                              id: "version",
                              "onUpdate:modelValue": ($event) => unref(editForm).version = $event,
                              placeholder: "Enter Your Version"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(editForm).version]
                            ]),
                            __props.errors.version ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.version), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mt-2" }, [
                            createVNode("label", {
                              for: "version_code",
                              class: "text-lg font-semibold"
                            }, "Version Code"),
                            withDirectives(createVNode("input", {
                              type: "text",
                              class: "form-input px-4 py-3 rounded-md w-full my-2",
                              id: "version_code",
                              "onUpdate:modelValue": ($event) => unref(editForm).version_code = $event,
                              placeholder: "Enter Your Version Code"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(editForm).version_code]
                            ]),
                            __props.errors.version_code ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.version_code), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mt-2" }, [
                            createVNode("label", {
                              for: "minimum_android",
                              class: "text-lg font-semibold"
                            }, "Minimum Android"),
                            withDirectives(createVNode("input", {
                              type: "text",
                              class: "form-input px-4 py-3 rounded-md w-full my-2",
                              id: "minimum_android",
                              "onUpdate:modelValue": ($event) => unref(editForm).minimum_android = $event,
                              placeholder: "Enter Your Minimum Android"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(editForm).minimum_android]
                            ]),
                            __props.errors.minimum_android ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.minimum_android), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mt-2" }, [
                            createVNode("label", {
                              for: "target_android",
                              class: "text-lg font-semibold"
                            }, "Target Android"),
                            withDirectives(createVNode("input", {
                              type: "text",
                              class: "form-input px-4 py-3 rounded-md w-full my-2",
                              id: "target_android",
                              "onUpdate:modelValue": ($event) => unref(editForm).target_android = $event,
                              placeholder: "Enter Your Target Android"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(editForm).target_android]
                            ]),
                            __props.errors.target_android ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.target_android), 1)) : createCommentVNode("", true)
                          ]),
                          createTextVNode(),
                          createVNode("div", { class: "mt-2" }, [
                            createVNode("label", {
                              for: "minimum_android_level",
                              class: "text-lg font-semibold"
                            }, "Minimum Android Level"),
                            withDirectives(createVNode("input", {
                              type: "text",
                              class: "form-input px-4 py-3 rounded-md w-full my-2",
                              id: "minimum_android_level",
                              "onUpdate:modelValue": ($event) => unref(editForm).minimum_android_level = $event,
                              placeholder: "Enter Your Minimum Android Level"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(editForm).minimum_android_level]
                            ]),
                            __props.errors.minimum_android_level ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.minimum_android_level), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mt-2" }, [
                            createVNode("label", {
                              for: "target_android_level",
                              class: "text-lg font-semibold"
                            }, "Target Android Level"),
                            withDirectives(createVNode("input", {
                              type: "text",
                              class: "form-input px-4 py-3 rounded-md w-full my-2",
                              id: "target_android_level",
                              "onUpdate:modelValue": ($event) => unref(editForm).target_android_level = $event,
                              placeholder: "Enter Your Target Android Level"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(editForm).target_android_level]
                            ]),
                            __props.errors.target_android_level ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.target_android_level), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mt-2" }, [
                            createVNode("label", {
                              for: "architecture",
                              class: "text-lg font-semibold"
                            }, "Architecture"),
                            withDirectives(createVNode("input", {
                              type: "text",
                              class: "form-input px-4 py-3 rounded-md w-full my-2",
                              id: "architecture",
                              "onUpdate:modelValue": ($event) => unref(editForm).architecture = $event,
                              placeholder: "Enter Your Architecture"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(editForm).architecture]
                            ]),
                            __props.errors.architecture ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.architecture), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mt-2" }, [
                            createVNode("label", {
                              for: "screen_dpi",
                              class: "text-lg font-semibold"
                            }, "Screen DPI"),
                            withDirectives(createVNode("input", {
                              type: "text",
                              class: "form-input px-4 py-3 rounded-md w-full my-2",
                              id: "screen_dpi",
                              "onUpdate:modelValue": ($event) => unref(editForm).screen_dpi = $event,
                              placeholder: "Enter Your Screen DPI"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(editForm).screen_dpi]
                            ]),
                            __props.errors.screen_dpi ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.screen_dpi), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mt-2" }, [
                            createVNode("label", {
                              for: "languages",
                              class: "text-lg font-semibold"
                            }, "Languages"),
                            withDirectives(createVNode("input", {
                              type: "text",
                              class: "form-input px-4 py-3 rounded-md w-full my-2",
                              id: "languages",
                              "onUpdate:modelValue": ($event) => unref(editForm).languages = $event,
                              placeholder: "Enter Your Languages"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(editForm).languages]
                            ]),
                            __props.errors.languages ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.languages), 1)) : createCommentVNode("", true)
                          ]),
                          createVNode("div", { class: "mt-2" }, [
                            createVNode("label", {
                              for: "date",
                              class: "text-lg font-semibold"
                            }, "Date"),
                            withDirectives(createVNode("input", {
                              type: "date",
                              class: "form-input px-4 py-3 rounded-md w-full my-2",
                              id: "date",
                              "onUpdate:modelValue": ($event) => unref(editForm).date = $event
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, unref(editForm).date]
                            ]),
                            __props.errors.date ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.date), 1)) : createCommentVNode("", true)
                          ])
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "date",
                            class: "text-lg font-semibold"
                          }, "What's New"),
                          createVNode(_sfc_main$3, {
                            modelValue: unref(form).whats_new,
                            "onUpdate:modelValue": ($event) => unref(form).whats_new = $event
                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                        ]),
                        createVNode("div", { class: "mt-2 flex space-x-4 justify-items-center items-center" }, [
                          createVNode("label", {
                            for: "name",
                            class: "text-lg font-semibold"
                          }, "Publish Status"),
                          createVNode(unref(Switch), {
                            modelValue: unref(editForm).status,
                            "onUpdate:modelValue": ($event) => unref(editForm).status = $event,
                            as: "template"
                          }, {
                            default: withCtx(({ checked }) => [
                              createVNode("button", {
                                class: ["relative inline-flex h-6 w-11 items-center rounded-full", checked ? "bg-blue-600" : "bg-red-500"]
                              }, [
                                createVNode("span", { class: "sr-only" }, "Enable"),
                                createVNode("span", {
                                  class: [checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"]
                                }, null, 2)
                              ], 2)
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"]),
                          __props.errors.status ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.status), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-4 float-end space-x-2" }, [
                          createVNode("button", {
                            type: "button",
                            class: "inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                            onClick: update
                          }, " Submit "),
                          createVNode("button", {
                            type: "button",
                            class: "inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                            onClick: closeUpdateModal
                          }, "Cancel ")
                        ])
                      ])
                    ]),
                    _: 1
                  }, 8, ["show"]),
                  createVNode(_sfc_main$2, { show: _ctx.isShowDelete }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "pb-10 m-10 border-x border-t rounded-md" }, [
                        createVNode("div", { class: "flex justify-between justify-items-center items-center p-1 mb-2 rounded-md" }, [
                          createVNode(_component_DialogTitle, {
                            as: "h3",
                            class: "text-lg font-medium leading-6 text-gray-900"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Delete App ")
                            ]),
                            _: 1
                          }),
                          createVNode("div", null, [
                            createVNode("button", {
                              type: "button",
                              class: "text-5xl leading-6 text-gray-400 font-normal",
                              onClick: _ctx.closeDeleteModal,
                              "data-bs-dismiss": "modal",
                              "aria-label": "Close"
                            }, " × ", 8, ["onClick"])
                          ])
                        ]),
                        createVNode("hr"),
                        createVNode("div", { class: "bg-red-100 p-5 text-red-700 space-y-2 rounded-md" }, [
                          createVNode("h2", { class: "flex space-x-2" }, [
                            createVNode(_component_ion_icon, {
                              name: "alert-circle-outline",
                              class: "text-3xl"
                            }),
                            createVNode("span", { class: "text-2xl" }, "Delete App")
                          ]),
                          createVNode("p", { class: "px-10" }, "You are sure you want to delete it?")
                        ]),
                        createVNode("div", { class: "mt-4 space-x-2 float-end" }, [
                          createVNode("button", {
                            type: "button",
                            class: "inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                            onClick: _ctx.deleteCategory
                          }, " Delete ", 8, ["onClick"]),
                          createVNode("button", {
                            type: "button",
                            class: "inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                            onClick: _ctx.closeDeleteModal
                          }, "Cancel ", 8, ["onClick"])
                        ])
                      ])
                    ]),
                    _: 1
                  }, 8, ["show"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Scrape/View.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
