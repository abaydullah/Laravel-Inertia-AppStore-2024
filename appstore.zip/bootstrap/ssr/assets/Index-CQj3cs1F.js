import { unref, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./FrontendLayout-CAfbY_H6.js";
import { Head } from "@inertiajs/vue3";
/* empty css                  */
import _sfc_main$2 from "./Latest-sAxxyEGp.js";
import Carousel from "./Carousel-DJzYU71g.js";
import "./ApplicationLogo-3H3I4iid.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./NavLink-CscBEwLF.js";
import "@headlessui/vue";
import "./TextInput-D7U8fbl4.js";
import "./TopRated-BRRuMLjo.js";
import "vue3-star-ratings";
import "vue3-carousel";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    latest_apps: Object,
    latest_games: Object,
    popular_apps: Object,
    hot_apps: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<title${_scopeId}>Home</title>`);
          } else {
            return [
              createVNode("title", null, "Home")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="overflow-hidden bg-white shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6 text-gray-900"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(Carousel, { apps: __props.popular_apps }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              apps: __props.latest_apps,
              label: "Latest Apps"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              apps: __props.latest_games,
              label: "Latest Games"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              apps: __props.popular_apps,
              label: "Popular Apps"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$2, {
              apps: __props.hot_apps,
              label: "Hot Apps"
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg" }, [
                createVNode("div", { class: "p-6 text-gray-900" }, [
                  createVNode("div", null, [
                    createVNode(Carousel, { apps: __props.popular_apps }, null, 8, ["apps"]),
                    createVNode(_sfc_main$2, {
                      apps: __props.latest_apps,
                      label: "Latest Apps"
                    }, null, 8, ["apps"]),
                    createVNode(_sfc_main$2, {
                      apps: __props.latest_games,
                      label: "Latest Games"
                    }, null, 8, ["apps"]),
                    createVNode(_sfc_main$2, {
                      apps: __props.popular_apps,
                      label: "Popular Apps"
                    }, null, 8, ["apps"]),
                    createVNode(_sfc_main$2, {
                      apps: __props.hot_apps,
                      label: "Hot Apps"
                    }, null, 8, ["apps"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Home/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
