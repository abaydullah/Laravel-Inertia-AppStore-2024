import { mergeProps, unref, withCtx, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle, ssrRenderComponent, ssrRenderList, ssrRenderAttr } from "vue/server-renderer";
import vue3StarRatings from "vue3-star-ratings";
import { Link } from "@inertiajs/vue3";
/* empty css                  */
import { Carousel, Navigation, Slide } from "vue3-carousel";
const _sfc_main = {
  __name: "Latest",
  __ssrInlineRender: true,
  props: {
    apps: Object,
    label: String
  },
  setup(__props) {
    const config = {
      itemsToShow: 1,
      snapAlign: "center",
      // 'breakpointMode' determines how the carousel breakpoints are calculated
      // Acceptable values: 'viewport' (default) | 'carousel'
      // 'viewport' - breakpoints are based on the viewport width
      // 'carousel' - breakpoints are based on the carousel width
      breakpointMode: "carousel",
      // Breakpoints are mobile-first
      // Any settings not specified will fall back to the carousel's default settings
      breakpoints: {
        // 300px and up
        280: {
          itemsToShow: 2,
          snapAlign: "center"
        },
        // 400px and up
        340: {
          itemsToShow: 3,
          snapAlign: "start"
        },
        // 400px and up
        450: {
          itemsToShow: 4,
          snapAlign: "start"
        },
        // 400px and up
        620: {
          itemsToShow: 5,
          snapAlign: "start"
        },
        // 600px and up
        720: {
          itemsToShow: 6,
          snapAlign: "start"
        },
        1050: {
          itemsToShow: 7,
          snapAlign: "start"
        },
        // 500px and up
        1200: {
          itemsToShow: 8,
          snapAlign: "start"
        },
        // 500px and up
        1300: {
          itemsToShow: 9,
          snapAlign: "start"
        }
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "py-5 shadow-2xl" }, _attrs))}><div class="flex justify-between p-2 border-x-8 border-y-2 bg-emerald-700 ring-2 outline-4 rounded-md font-semibold text-white mb-5"><h2 class="">${ssrInterpolate(__props.label)}</h2><a href="#" class="">More</a></div><div class="" style="${ssrRenderStyle({ "resize": "horizontal", "overflow": "auto" })}">`);
      _push(ssrRenderComponent(unref(Carousel), config, {
        addons: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(Navigation), null, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(Navigation))
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(__props.apps, (app, key) => {
              _push2(ssrRenderComponent(unref(Slide), { key }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="carousel__item"${_scopeId2}><div${_scopeId2}>`);
                    _push3(ssrRenderComponent(unref(Link), {
                      href: _ctx.route("app.view", app)
                    }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<div class="shadow-sm rounded p-1 hover:bg-gray-200 border ring-2 hover:border-amber-300 hover:ring-yellow-500 transition-all duration-200 hover:ring-4"${_scopeId3}><img${ssrRenderAttr("src", app.icon)} alt="" width="120" class="rounded object-cover"${_scopeId3}><h5 class="text-sm text-center"${_scopeId3}>${ssrInterpolate(app.title.substring(0, 12))}</h5><div class="flex items-center justify-between py-2 px-2"${_scopeId3}><span${_scopeId3}>${ssrInterpolate(app.rating)}</span>`);
                          _push4(ssrRenderComponent(unref(vue3StarRatings), {
                            "star-size": "15",
                            modelValue: app.rating,
                            "onUpdate:modelValue": ($event) => app.rating = $event,
                            "disable-click": "",
                            inactiveColor: "#cbd5e1"
                          }, null, _parent4, _scopeId3));
                          _push4(`</div></div>`);
                        } else {
                          return [
                            createVNode("div", { class: "shadow-sm rounded p-1 hover:bg-gray-200 border ring-2 hover:border-amber-300 hover:ring-yellow-500 transition-all duration-200 hover:ring-4" }, [
                              createVNode("img", {
                                src: app.icon,
                                alt: "",
                                width: "120",
                                class: "rounded object-cover"
                              }, null, 8, ["src"]),
                              createVNode("h5", { class: "text-sm text-center" }, toDisplayString(app.title.substring(0, 12)), 1),
                              createVNode("div", { class: "flex items-center justify-between py-2 px-2" }, [
                                createVNode("span", null, toDisplayString(app.rating), 1),
                                createVNode(unref(vue3StarRatings), {
                                  "star-size": "15",
                                  modelValue: app.rating,
                                  "onUpdate:modelValue": ($event) => app.rating = $event,
                                  "disable-click": "",
                                  inactiveColor: "#cbd5e1"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ])
                            ])
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                    _push3(`</div></div>`);
                  } else {
                    return [
                      createVNode("div", { class: "carousel__item" }, [
                        createVNode("div", null, [
                          createVNode(unref(Link), {
                            href: _ctx.route("app.view", app)
                          }, {
                            default: withCtx(() => [
                              createVNode("div", { class: "shadow-sm rounded p-1 hover:bg-gray-200 border ring-2 hover:border-amber-300 hover:ring-yellow-500 transition-all duration-200 hover:ring-4" }, [
                                createVNode("img", {
                                  src: app.icon,
                                  alt: "",
                                  width: "120",
                                  class: "rounded object-cover"
                                }, null, 8, ["src"]),
                                createVNode("h5", { class: "text-sm text-center" }, toDisplayString(app.title.substring(0, 12)), 1),
                                createVNode("div", { class: "flex items-center justify-between py-2 px-2" }, [
                                  createVNode("span", null, toDisplayString(app.rating), 1),
                                  createVNode(unref(vue3StarRatings), {
                                    "star-size": "15",
                                    modelValue: app.rating,
                                    "onUpdate:modelValue": ($event) => app.rating = $event,
                                    "disable-click": "",
                                    inactiveColor: "#cbd5e1"
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ])
                              ])
                            ]),
                            _: 2
                          }, 1032, ["href"])
                        ])
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(__props.apps, (app, key) => {
                return openBlock(), createBlock(unref(Slide), { key }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "carousel__item" }, [
                      createVNode("div", null, [
                        createVNode(unref(Link), {
                          href: _ctx.route("app.view", app)
                        }, {
                          default: withCtx(() => [
                            createVNode("div", { class: "shadow-sm rounded p-1 hover:bg-gray-200 border ring-2 hover:border-amber-300 hover:ring-yellow-500 transition-all duration-200 hover:ring-4" }, [
                              createVNode("img", {
                                src: app.icon,
                                alt: "",
                                width: "120",
                                class: "rounded object-cover"
                              }, null, 8, ["src"]),
                              createVNode("h5", { class: "text-sm text-center" }, toDisplayString(app.title.substring(0, 12)), 1),
                              createVNode("div", { class: "flex items-center justify-between py-2 px-2" }, [
                                createVNode("span", null, toDisplayString(app.rating), 1),
                                createVNode(unref(vue3StarRatings), {
                                  "star-size": "15",
                                  modelValue: app.rating,
                                  "onUpdate:modelValue": ($event) => app.rating = $event,
                                  "disable-click": "",
                                  inactiveColor: "#cbd5e1"
                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                              ])
                            ])
                          ]),
                          _: 2
                        }, 1032, ["href"])
                      ])
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Home/Partials/Latest.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
