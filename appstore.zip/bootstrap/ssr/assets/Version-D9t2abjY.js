import { ref, resolveComponent, unref, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, createCommentVNode, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderStyle, ssrInterpolate, ssrRenderAttr, ssrRenderList } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./FrontendLayout-CAfbY_H6.js";
import { Head, Link } from "@inertiajs/vue3";
/* empty css                  */
import vue3StarRatings from "vue3-star-ratings";
import "vue-easy-lightbox/dist/external-css/vue-easy-lightbox.esm.min.js";
/* empty css                           */
import "vue-select";
import { _ as _sfc_main$2 } from "./Modal-_hjahxgY.js";
import "./ApplicationLogo-3H3I4iid.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./NavLink-CscBEwLF.js";
import "@headlessui/vue";
import "./TextInput-D7U8fbl4.js";
import "./TopRated-BRRuMLjo.js";
const _sfc_main = {
  __name: "Version",
  __ssrInlineRender: true,
  props: {
    app: Object,
    version: Object
  },
  setup(__props) {
    const props = __props;
    const pluck = (arr, key) => arr.map((i) => i[key]);
    pluck(props.app.screenshots, "photo");
    ref(false);
    ref(0);
    ref("max-h-[160px] overflow-hidden");
    const isShow = ref(false);
    const openModal = () => {
      isShow.value = true;
    };
    const closeModal = () => {
      isShow.value = false;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ion_icon = resolveComponent("ion-icon");
      const _component_DialogTitle = resolveComponent("DialogTitle");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<title${_scopeId}>Home</title>`);
          } else {
            return [
              createVNode("title", null, "Home")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
          if (_push2) {
            _push2(`<div class="overflow-hidden bg-white shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6 text-gray-900 md:bg-no-repeat bg-right md:bg-contain rounded-md" style="${ssrRenderStyle(`background-image: url('${__props.app.cover_image}')`)}"${_scopeId}><div class="flex"${_scopeId}><span class="flex items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              class: "text-cyan-500 font-semibold hover:text-indigo-600",
              href: _ctx.route("home")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Home`);
                } else {
                  return [
                    createTextVNode("Home")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(` `);
            _push2(ssrRenderComponent(_component_ion_icon, {
              name: "chevron-forward-outline",
              class: "text-2xl text-cyan-500 font-extrabold"
            }, null, _parent2, _scopeId));
            _push2(`</span><span class="flex items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              class: "text-cyan-500 font-semibold hover:text-indigo-600",
              href: _ctx.route("app.index")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Apps`);
                } else {
                  return [
                    createTextVNode("Apps")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(` `);
            _push2(ssrRenderComponent(_component_ion_icon, {
              name: "chevron-forward-outline",
              class: "text-2xl text-cyan-500 font-extrabold"
            }, null, _parent2, _scopeId));
            _push2(`</span><span class="flex items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              class: "text-cyan-500 font-semibold hover:text-indigo-600",
              href: _ctx.route("categories.view", __props.app.category)
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(__props.app.category.name)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(__props.app.category.name), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(` `);
            _push2(ssrRenderComponent(_component_ion_icon, {
              name: "chevron-forward-outline",
              class: "text-2xl text-cyan-500 font-extrabold"
            }, null, _parent2, _scopeId));
            _push2(`</span><span class="flex items-center"${_scopeId}>${ssrInterpolate(__props.app.title)}</span></div><div class="flex space-x-3 mt-5"${_scopeId}><div class="rounded-md"${_scopeId}><img${ssrRenderAttr("src", __props.app.icon)} alt="" width="240" class="object-cover rounded-md"${_scopeId}><div class="text-center capitalize text-5xl shadow-md bg-emerald-500 text-white rounded-md"${_scopeId}>${ssrInterpolate(__props.app.type)}</div></div><div class="flex flex-col space-y-2"${_scopeId}><h1 class="text-5xl"${_scopeId}>${ssrInterpolate(__props.app.title)}</h1><span class="text-lg"${_scopeId}>Category: <a class="text-indigo-600 font-semibold"${ssrRenderAttr("href", _ctx.route("categories.view", __props.app.category))}${_scopeId}>${ssrInterpolate((_b = (_a = __props.app) == null ? void 0 : _a.category) == null ? void 0 : _b.name)}</a></span>`);
            if ((_c = __props.app) == null ? void 0 : _c.developer) {
              _push2(`<span class="text-lg"${_scopeId}>Developer: <a class="text-indigo-600 font-semibold"${ssrRenderAttr("href", _ctx.route("developers.view", (_d = __props.app) == null ? void 0 : _d.developer))}${_scopeId}>${ssrInterpolate((_f = (_e = __props.app) == null ? void 0 : _e.developer) == null ? void 0 : _f.name)}</a></span>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex space-x-3 items-center"${_scopeId}><span class="text-4xl"${_scopeId}>${ssrInterpolate(__props.app.rating)}</span>`);
            _push2(ssrRenderComponent(unref(vue3StarRatings), {
              modelValue: __props.app.rating,
              "onUpdate:modelValue": ($event) => __props.app.rating = $event,
              "star-size": "40",
              inactiveColor: "#cbd5e1",
              disableClick: true
            }, null, _parent2, _scopeId));
            _push2(`</div><span class="text-lg mt-5 flex space-x-2"${_scopeId}><span class="text-lg"${_scopeId}>Google Play: </span><a class="text-indigo-600 font-semibold"${ssrRenderAttr("href", __props.app.url)}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_ion_icon, {
              name: "logo-google-playstore",
              class: "text-2xl text-cyan-500 font-extrabold"
            }, null, _parent2, _scopeId));
            _push2(`</a></span><span class="text-lg mt-5"${_scopeId}><span class="text-lg"${_scopeId}> Updated On: </span> ${ssrInterpolate(__props.app.updated_at)}</span><div${_scopeId}>`);
            if (__props.app.trailer) {
              _push2(`<button class="text-white bg-gray-800 text-lg py-2 px-4 rounded-lg justify-center items-center flex"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_ion_icon, {
                name: "play-outline",
                class: "text-white text-xl pr-1"
              }, null, _parent2, _scopeId));
              _push2(` <span${_scopeId}>Trailer</span></button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div></div></div><div class="overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2"${_scopeId}>`);
            if (__props.version.whats_new) {
              _push2(`<div class="py-4 px-5"${_scopeId}><h3${_scopeId}>What&#39;s New</h3><p class="text-lg"${_scopeId}>${__props.version.whats_new ?? ""}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2"${_scopeId}><div class="py-4 px-5"${_scopeId}><h3 class="py-4 text-xl"${_scopeId}>More Information</h3><div class="flex justify-between"${_scopeId}><span${_scopeId}>Package Name<br${_scopeId}>${ssrInterpolate(__props.app.app_id)}</span><span${_scopeId}>Languages<br${_scopeId}></span></div><div class="flex justify-between"${_scopeId}><span${_scopeId}>Requires Android<br${_scopeId}>${ssrInterpolate(__props.version.minimum_android)}+ (${ssrInterpolate(__props.version.minimum_android_level)})</span><span${_scopeId}>Target Android<br${_scopeId}>${ssrInterpolate(__props.version.target_android)}+ (${ssrInterpolate(__props.version.target_android_level)})</span></div></div></div><div class="overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2"${_scopeId}>`);
            if (__props.app.versions > 100) {
              _push2(`<div class="py-4 px-5"${_scopeId}><h3 class="mb-4 text-2xl"${_scopeId}>Versions History of ${ssrInterpolate(__props.app.title)}</h3><div class="divide-y py-5"${_scopeId}><!--[-->`);
              ssrRenderList(__props.app.versions, (version) => {
                _push2(`<div class=""${_scopeId}><div class="text-lg flex justify-between"${_scopeId}><a href="" class="py-2 text-gray-700 hover:text-indigo-700 hover:font-semibold"${_scopeId}><h3${_scopeId}>v${ssrInterpolate(version.version)} (${ssrInterpolate(version.version_code)})</h3><div class="space-x-6 text-gray-400"${_scopeId}><span${_scopeId}>${ssrInterpolate(version.file_size)}</span><span${_scopeId}>${ssrInterpolate(version.date_format)}</span></div></a><div${_scopeId}><button class="px-3 py-1 bg-green-500 text-white flex items-center space-x-2 hover:bg-green-400 rounded-md"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_ion_icon, { name: "arrow-down-circle-outline" }, null, _parent2, _scopeId));
                _push2(` <span${_scopeId}>Download</span></button></div></div></div>`);
              });
              _push2(`<!--]--></div><div class="text-center pt-5 border-t"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                class: "px-32 py-2 bg-gray-50 border-2 border-green-500 hover:border-green-200 rounded-md hover:bg-green-500 hover:text-gray-50 transition-all duration-300",
                href: _ctx.route("app.view.versions", __props.app.slug)
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(` All Versions `);
                  } else {
                    return [
                      createTextVNode(" All Versions ")
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              show: isShow.value,
              class: "w-full"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="px-5 pb-5 my-5"${_scopeId2}><div class="flex justify-between justify-items-center items-center py-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_DialogTitle, {
                    as: "h3",
                    class: "text-lg font-medium leading-6 text-gray-900"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Add New Category `);
                      } else {
                        return [
                          createTextVNode(" Add New Category ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div${_scopeId2}><button type="button" class="text-5xl leading-6 text-gray-400 font-normal" data-bs-dismiss="modal" aria-label="Close"${_scopeId2}> × </button></div></div><hr${_scopeId2}><div class="mt-4 float-end space-x-2"${_scopeId2}><iframe class="w-[920px] aspect-video"${ssrRenderAttr("src", __props.app.trailer)}${_scopeId2}></iframe></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "px-5 pb-5 my-5" }, [
                      createVNode("div", { class: "flex justify-between justify-items-center items-center py-2" }, [
                        createVNode(_component_DialogTitle, {
                          as: "h3",
                          class: "text-lg font-medium leading-6 text-gray-900"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Add New Category ")
                          ]),
                          _: 1
                        }),
                        createVNode("div", null, [
                          createVNode("button", {
                            type: "button",
                            class: "text-5xl leading-6 text-gray-400 font-normal",
                            onClick: closeModal,
                            "data-bs-dismiss": "modal",
                            "aria-label": "Close"
                          }, " × ")
                        ])
                      ]),
                      createVNode("hr"),
                      createVNode("div", { class: "mt-4 float-end space-x-2" }, [
                        createVNode("iframe", {
                          class: "w-[920px] aspect-video",
                          src: __props.app.trailer
                        }, null, 8, ["src"])
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg" }, [
                createVNode("div", {
                  class: "p-6 text-gray-900 md:bg-no-repeat bg-right md:bg-contain rounded-md",
                  style: `background-image: url('${__props.app.cover_image}')`
                }, [
                  createVNode("div", { class: "flex" }, [
                    createVNode("span", { class: "flex items-center" }, [
                      createVNode(unref(Link), {
                        class: "text-cyan-500 font-semibold hover:text-indigo-600",
                        href: _ctx.route("home")
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Home")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createTextVNode(),
                      createVNode(_component_ion_icon, {
                        name: "chevron-forward-outline",
                        class: "text-2xl text-cyan-500 font-extrabold"
                      })
                    ]),
                    createVNode("span", { class: "flex items-center" }, [
                      createVNode(unref(Link), {
                        class: "text-cyan-500 font-semibold hover:text-indigo-600",
                        href: _ctx.route("app.index")
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Apps")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createTextVNode(),
                      createVNode(_component_ion_icon, {
                        name: "chevron-forward-outline",
                        class: "text-2xl text-cyan-500 font-extrabold"
                      })
                    ]),
                    createVNode("span", { class: "flex items-center" }, [
                      createVNode(unref(Link), {
                        class: "text-cyan-500 font-semibold hover:text-indigo-600",
                        href: _ctx.route("categories.view", __props.app.category)
                      }, {
                        default: withCtx(() => [
                          createTextVNode(toDisplayString(__props.app.category.name), 1)
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createTextVNode(),
                      createVNode(_component_ion_icon, {
                        name: "chevron-forward-outline",
                        class: "text-2xl text-cyan-500 font-extrabold"
                      })
                    ]),
                    createVNode("span", { class: "flex items-center" }, toDisplayString(__props.app.title), 1)
                  ]),
                  createVNode("div", { class: "flex space-x-3 mt-5" }, [
                    createVNode("div", { class: "rounded-md" }, [
                      createVNode("img", {
                        src: __props.app.icon,
                        alt: "",
                        width: "240",
                        class: "object-cover rounded-md"
                      }, null, 8, ["src"]),
                      createVNode("div", { class: "text-center capitalize text-5xl shadow-md bg-emerald-500 text-white rounded-md" }, toDisplayString(__props.app.type), 1)
                    ]),
                    createVNode("div", { class: "flex flex-col space-y-2" }, [
                      createVNode("h1", { class: "text-5xl" }, toDisplayString(__props.app.title), 1),
                      createVNode("span", { class: "text-lg" }, [
                        createTextVNode("Category: "),
                        createVNode("a", {
                          class: "text-indigo-600 font-semibold",
                          href: _ctx.route("categories.view", __props.app.category)
                        }, toDisplayString((_h = (_g = __props.app) == null ? void 0 : _g.category) == null ? void 0 : _h.name), 9, ["href"])
                      ]),
                      ((_i = __props.app) == null ? void 0 : _i.developer) ? (openBlock(), createBlock("span", {
                        key: 0,
                        class: "text-lg"
                      }, [
                        createTextVNode("Developer: "),
                        createVNode("a", {
                          class: "text-indigo-600 font-semibold",
                          href: _ctx.route("developers.view", (_j = __props.app) == null ? void 0 : _j.developer)
                        }, toDisplayString((_l = (_k = __props.app) == null ? void 0 : _k.developer) == null ? void 0 : _l.name), 9, ["href"])
                      ])) : createCommentVNode("", true),
                      createVNode("div", { class: "flex space-x-3 items-center" }, [
                        createVNode("span", { class: "text-4xl" }, toDisplayString(__props.app.rating), 1),
                        createVNode(unref(vue3StarRatings), {
                          modelValue: __props.app.rating,
                          "onUpdate:modelValue": ($event) => __props.app.rating = $event,
                          "star-size": "40",
                          inactiveColor: "#cbd5e1",
                          disableClick: true
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("span", { class: "text-lg mt-5 flex space-x-2" }, [
                        createVNode("span", { class: "text-lg" }, "Google Play: "),
                        createVNode("a", {
                          class: "text-indigo-600 font-semibold",
                          href: __props.app.url
                        }, [
                          createVNode(_component_ion_icon, {
                            name: "logo-google-playstore",
                            class: "text-2xl text-cyan-500 font-extrabold"
                          })
                        ], 8, ["href"])
                      ]),
                      createVNode("span", { class: "text-lg mt-5" }, [
                        createVNode("span", { class: "text-lg" }, " Updated On: "),
                        createTextVNode(" " + toDisplayString(__props.app.updated_at), 1)
                      ]),
                      createVNode("div", null, [
                        __props.app.trailer ? (openBlock(), createBlock("button", {
                          key: 0,
                          class: "text-white bg-gray-800 text-lg py-2 px-4 rounded-lg justify-center items-center flex",
                          onClick: openModal
                        }, [
                          createVNode(_component_ion_icon, {
                            name: "play-outline",
                            class: "text-white text-xl pr-1"
                          }),
                          createTextVNode(),
                          createVNode("span", null, "Trailer")
                        ])) : createCommentVNode("", true)
                      ])
                    ])
                  ])
                ], 4)
              ]),
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2" }, [
                __props.version.whats_new ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "py-4 px-5"
                }, [
                  createVNode("h3", null, "What's New"),
                  createVNode("p", {
                    class: "text-lg",
                    innerHTML: __props.version.whats_new
                  }, null, 8, ["innerHTML"])
                ])) : createCommentVNode("", true)
              ]),
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2" }, [
                createVNode("div", { class: "py-4 px-5" }, [
                  createVNode("h3", { class: "py-4 text-xl" }, "More Information"),
                  createVNode("div", { class: "flex justify-between" }, [
                    createVNode("span", null, [
                      createTextVNode("Package Name"),
                      createVNode("br"),
                      createTextVNode(toDisplayString(__props.app.app_id), 1)
                    ]),
                    createVNode("span", null, [
                      createTextVNode("Languages"),
                      createVNode("br")
                    ])
                  ]),
                  createVNode("div", { class: "flex justify-between" }, [
                    createVNode("span", null, [
                      createTextVNode("Requires Android"),
                      createVNode("br"),
                      createTextVNode(toDisplayString(__props.version.minimum_android) + "+ (" + toDisplayString(__props.version.minimum_android_level) + ")", 1)
                    ]),
                    createVNode("span", null, [
                      createTextVNode("Target Android"),
                      createVNode("br"),
                      createTextVNode(toDisplayString(__props.version.target_android) + "+ (" + toDisplayString(__props.version.target_android_level) + ")", 1)
                    ])
                  ])
                ])
              ]),
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2" }, [
                __props.app.versions > 100 ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "py-4 px-5"
                }, [
                  createVNode("h3", { class: "mb-4 text-2xl" }, "Versions History of " + toDisplayString(__props.app.title), 1),
                  createVNode("div", { class: "divide-y py-5" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.app.versions, (version) => {
                      return openBlock(), createBlock("div", { class: "" }, [
                        createVNode("div", { class: "text-lg flex justify-between" }, [
                          createVNode("a", {
                            href: "",
                            class: "py-2 text-gray-700 hover:text-indigo-700 hover:font-semibold"
                          }, [
                            createVNode("h3", null, "v" + toDisplayString(version.version) + " (" + toDisplayString(version.version_code) + ")", 1),
                            createVNode("div", { class: "space-x-6 text-gray-400" }, [
                              createVNode("span", null, toDisplayString(version.file_size), 1),
                              createVNode("span", null, toDisplayString(version.date_format), 1)
                            ])
                          ]),
                          createVNode("div", null, [
                            createVNode("button", { class: "px-3 py-1 bg-green-500 text-white flex items-center space-x-2 hover:bg-green-400 rounded-md" }, [
                              createVNode(_component_ion_icon, { name: "arrow-down-circle-outline" }),
                              createTextVNode(),
                              createVNode("span", null, "Download")
                            ])
                          ])
                        ])
                      ]);
                    }), 256))
                  ]),
                  createVNode("div", { class: "text-center pt-5 border-t" }, [
                    createVNode(unref(Link), {
                      class: "px-32 py-2 bg-gray-50 border-2 border-green-500 hover:border-green-200 rounded-md hover:bg-green-500 hover:text-gray-50 transition-all duration-300",
                      href: _ctx.route("app.view.versions", __props.app.slug)
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" All Versions ")
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ])
                ])) : createCommentVNode("", true)
              ]),
              createVNode(_sfc_main$2, {
                show: isShow.value,
                class: "w-full"
              }, {
                default: withCtx(() => [
                  createVNode("div", { class: "px-5 pb-5 my-5" }, [
                    createVNode("div", { class: "flex justify-between justify-items-center items-center py-2" }, [
                      createVNode(_component_DialogTitle, {
                        as: "h3",
                        class: "text-lg font-medium leading-6 text-gray-900"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Add New Category ")
                        ]),
                        _: 1
                      }),
                      createVNode("div", null, [
                        createVNode("button", {
                          type: "button",
                          class: "text-5xl leading-6 text-gray-400 font-normal",
                          onClick: closeModal,
                          "data-bs-dismiss": "modal",
                          "aria-label": "Close"
                        }, " × ")
                      ])
                    ]),
                    createVNode("hr"),
                    createVNode("div", { class: "mt-4 float-end space-x-2" }, [
                      createVNode("iframe", {
                        class: "w-[920px] aspect-video",
                        src: __props.app.trailer
                      }, null, 8, ["src"])
                    ])
                  ])
                ]),
                _: 1
              }, 8, ["show"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/App/Version.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
