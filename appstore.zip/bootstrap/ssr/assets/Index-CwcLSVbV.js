import { watch, ref, resolveComponent, unref, withCtx, createVNode, createTextVNode, withDirectives, vModelText, openBlock, createBlock, toDisplayString, createCommentVNode, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderStyle, ssrRenderList, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-DnYYwDfw.js";
import { useForm, router, Head } from "@inertiajs/vue3";
import { _ as _sfc_main$3 } from "./Modal-_hjahxgY.js";
import { Switch } from "@headlessui/vue";
/* empty css                    */
import VSelect from "vue-select";
import { _ as _sfc_main$2 } from "./Pagination-CzMcH4PS.js";
import { debounce } from "lodash";
import "./ApplicationLogo-3H3I4iid.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./NavLink-CscBEwLF.js";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    developers: Object,
    status: Number,
    search: String,
    type: Number,
    errors: Object
  },
  setup(__props) {
    const types = [{ "id": "app", "name": "App" }, { "id": "game", "name": "Game" }];
    const statusOptions = [{ "id": "", "name": "All" }, { "id": "1", "name": "Published" }, { "id": "0", "name": "Unpublished" }];
    const props = __props;
    const form = useForm({
      name: "",
      google_name: "",
      google_url: "",
      slug: "",
      type: "app",
      status: true
    });
    const editForm = useForm({
      _method: "PUT",
      id: "",
      name: "",
      google_name: "",
      google_url: "",
      slug: "",
      type: "app",
      status: true
    });
    watch(() => form.name, (name) => {
      form.slug = name.toLowerCase().replace(/[^\w ]+/g, "").replace(/ +/g, "-");
    });
    const isShow = ref(false);
    const closeModal = () => {
      isShow.value = false;
    };
    const submit = () => {
      form.post(route("admin.developers.store"), {
        preserveScroll: true,
        onSuccess: () => {
          isShow.value = false;
        }
      });
    };
    const isShowUpdate = ref(false);
    const openUpdateModal = (developer) => {
      isShowUpdate.value = true;
      editForm.id = developer.id;
      editForm.name = developer.name;
      editForm.google_name = developer.google_name;
      editForm.google_url = developer.google_url;
      editForm.slug = developer.slug;
      editForm.type = developer.type;
      editForm.status = developer.status;
    };
    const closeUpdateModal = () => {
      isShowUpdate.value = false;
    };
    const update = () => {
      editForm.post(route("admin.developers.update", editForm.id), {
        preserveScroll: true,
        onSuccess: () => {
          isShowUpdate.value = false;
        }
      });
    };
    const isShowDelete = ref(false);
    const openDeleteModal = (developer) => {
      isShowDelete.value = true;
      editForm.id = developer.id;
      editForm.name = developer.name;
      editForm.google_name = developer.google_name;
      editForm.google_url = developer.google_url;
      editForm.slug = developer.slug;
      editForm.type = developer.type;
      editForm.status = developer.status;
    };
    const closeDeleteModal = () => {
      isShowDelete.value = false;
    };
    const deleteDeveloper = () => {
      editForm.delete(route("admin.developers.destroy", editForm.id), {
        preserveScroll: true,
        onSuccess: () => {
          isShowDelete.value = false;
        }
      });
    };
    const search = ref(props.search);
    const type = ref(props.type);
    const status = ref(props.status);
    watch([search, type, status], debounce(function([searchData, appType, statusType]) {
      router.get(route("admin.developers.index", { search: searchData, type: appType, status: statusType }), {}, {
        preserveState: true,
        replace: true,
        onSuccess: () => {
        }
      });
    }), 300);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Header = resolveComponent("Header");
      const _component_ion_icon = resolveComponent("ion-icon");
      const _component_DialogTitle = resolveComponent("DialogTitle");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Developers" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        header: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h2 class="text-xl font-semibold leading-tight text-gray-800"${_scopeId}> Developers </h2>`);
          } else {
            return [
              createVNode("h2", { class: "text-xl font-semibold leading-tight text-gray-800" }, " Developers ")
            ];
          }
        }),
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="overflow-hidden bg-white shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6 text-gray-900"${_scopeId}><div id="content" class=""${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Header, { title: "main.developer-list" }, null, _parent2, _scopeId));
            _push2(`<div class="relative overflow-x-auto shadow-md sm:rounded-lg mt-5"${_scopeId}><div class="flex items-center justify-between flex-column flex-wrap md:flex-row space-y-4 md:space-y-0 pb-4 bg-white dark:bg-gray-900"${_scopeId}><div class="flex space-x-3"${_scopeId}><div${_scopeId}><label for="table-search" class=""${_scopeId}>Search</label><div class="relative"${_scopeId}><div class="absolute inset-y-0 rtl:inset-r-0 start-0 flex items-center ps-3 pointer-events-none"${_scopeId}><svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20"${_scopeId}><path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"${_scopeId}></path></svg></div><input${ssrRenderAttr("value", search.value)} type="text" id="table-search-users" class="block p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg w-80 bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Search for Developer"${_scopeId}></div></div><div class=""${_scopeId}><label for="type" class=""${_scopeId}>Status</label>`);
            _push2(ssrRenderComponent(unref(VSelect), {
              options: statusOptions,
              reduce: (status2) => status2.id,
              label: "name",
              class: "style-chooser w-48",
              modelValue: status.value,
              "onUpdate:modelValue": ($event) => status.value = $event
            }, null, _parent2, _scopeId));
            if (__props.errors.type) {
              _push2(`<span class="text-lg text-red-600 font-semibold"${_scopeId}>${ssrInterpolate(__props.errors.type)}</span>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div><div${_scopeId}></div></div>`);
            if (__props.developers) {
              _push2(`<div${_scopeId}><table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400" style="${ssrRenderStyle({ "width": "100%" })}"${_scopeId}><thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400"${_scopeId}><tr${_scopeId}><th scope="col" class="p-4" style="${ssrRenderStyle({ "width": "5%" })}"${_scopeId}> ID </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "10%" })}"${_scopeId}> Icon </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "25%" })}"${_scopeId}> Name </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "25%" })}"${_scopeId}> slug </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "10%" })}"${_scopeId}> Google Play </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "10%" })}"${_scopeId}> Status </th><th scope="col" class="px-6 py-3" style="${ssrRenderStyle({ "width": "15%" })}"${_scopeId}> Action </th></tr></thead><tbody${_scopeId}><!--[-->`);
              ssrRenderList(__props.developers.data, (developer, index) => {
                _push2(`<tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600"${_scopeId}><td class="p-4 text-lg font-semibold"${_scopeId}>${ssrInterpolate(index + 1)}</td><th scope="row" class="p-2"${_scopeId}>${ssrInterpolate(developer.icon)}</th><th scope="row" class="p-2"${_scopeId}>${ssrInterpolate(developer.name)}</th><td class="px-2 py-2"${_scopeId}>${ssrInterpolate(developer.slug)}</td><td class="px-2 py-2 capitalize"${_scopeId}><a target="_blank"${ssrRenderAttr("href", developer.google_url)}${_scopeId}>`);
                _push2(ssrRenderComponent(_component_ion_icon, {
                  name: "logo-google-playstore",
                  class: "text-2xl text-cyan-500 font-extrabold"
                }, null, _parent2, _scopeId));
                _push2(`</a></td><td class="px-2 py-2"${_scopeId}>`);
                if (developer.status) {
                  _push2(`<span class="bg-green-600 text-white py-1 px-2 rounded-md font-normal"${_scopeId}>Published</span>`);
                } else {
                  _push2(`<span class="bg-red-600 text-white py-1 px-2 rounded-md font-normal"${_scopeId}>Unpublished</span>`);
                }
                _push2(`</td><td class="px-2 py-2 space-x-3"${_scopeId}><a href="#" class="font-medium text-blue-600 dark:text-blue-500 hover:underline"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_ion_icon, {
                  name: "create",
                  class: "pt-2",
                  size: "large"
                }, null, _parent2, _scopeId));
                _push2(`</a><a href="#" class="font-medium text-blue-600 dark:text-blue-500 hover:underline"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_ion_icon, {
                  class: "pt-2 text-red-500",
                  name: "trash",
                  size: "large"
                }, null, _parent2, _scopeId));
                _push2(`</a></td></tr>`);
              });
              _push2(`<!--]--></tbody></table>`);
              _push2(ssrRenderComponent(_sfc_main$2, {
                meta: __props.developers.meta
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<div class="text-center text-4xl font-extrabold bg-gradient-to-t from-green-300 to-green-800 bg-clip-text text-transparent leading-normal"${_scopeId}> Data Not Found </div>`);
            }
            _push2(`</div></div>`);
            _push2(ssrRenderComponent(_sfc_main$3, { show: isShow.value }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="px-10 pb-10 my-10"${_scopeId2}><div class="flex justify-between justify-items-center items-center py-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_DialogTitle, {
                    as: "h3",
                    class: "text-lg font-medium leading-6 text-gray-900"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Add New Developer `);
                      } else {
                        return [
                          createTextVNode(" Add New Developer ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div${_scopeId2}><button type="button" class="text-5xl leading-6 text-gray-400 font-normal" data-bs-dismiss="modal" aria-label="Close"${_scopeId2}> × </button></div></div><hr${_scopeId2}><div class="mt-2"${_scopeId2}><label for="name" class="text-lg font-semibold"${_scopeId2}>Name</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="name"${ssrRenderAttr("value", unref(form).name)} placeholder="Enter Your Developer Name"${_scopeId2}>`);
                  if (__props.errors.name) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.name)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="slug" class="text-lg font-semibold"${_scopeId2}>Slug</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="slug"${ssrRenderAttr("value", unref(form).slug)} placeholder="Enter Your Developer Name"${_scopeId2}>`);
                  if (__props.errors.slug) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.slug)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="google_name" class="text-lg font-semibold"${_scopeId2}>Google Name</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="google_name"${ssrRenderAttr("value", unref(form).google_name)} placeholder="Enter Your Developer Google Name"${_scopeId2}>`);
                  if (__props.errors.google_name) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.google_name)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="google_url" class="text-lg font-semibold"${_scopeId2}>Google Url</label><input type="url" class="form-input px-4 py-3 rounded-md w-full my-2" id="google_url"${ssrRenderAttr("value", unref(form).google_url)} placeholder="Enter Your Developer Google URL"${_scopeId2}>`);
                  if (__props.errors.google_url) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.google_url)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="type" class="text-lg font-semibold"${_scopeId2}>Type</label>`);
                  _push3(ssrRenderComponent(unref(VSelect), {
                    options: types,
                    reduce: (type2) => type2.id,
                    label: "name",
                    class: "style-chooser1 mt-2",
                    modelValue: unref(form).type,
                    "onUpdate:modelValue": ($event) => unref(form).type = $event
                  }, null, _parent3, _scopeId2));
                  if (__props.errors.type) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.type)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2 flex space-x-4 justify-items-center items-center"${_scopeId2}><label for="name" class="text-lg font-semibold"${_scopeId2}>Publish Status</label>`);
                  _push3(ssrRenderComponent(unref(Switch), {
                    modelValue: unref(form).status,
                    "onUpdate:modelValue": ($event) => unref(form).status = $event,
                    as: "template"
                  }, {
                    default: withCtx(({ checked }, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<button class="${ssrRenderClass([checked ? "bg-blue-600" : "bg-red-500", "relative inline-flex h-6 w-11 items-center rounded-full"])}"${_scopeId3}><span class="sr-only"${_scopeId3}>Enable</span><span class="${ssrRenderClass([checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"])}"${_scopeId3}></span></button>`);
                      } else {
                        return [
                          createVNode("button", {
                            class: ["relative inline-flex h-6 w-11 items-center rounded-full", checked ? "bg-blue-600" : "bg-red-500"]
                          }, [
                            createVNode("span", { class: "sr-only" }, "Enable"),
                            createVNode("span", {
                              class: [checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"]
                            }, null, 2)
                          ], 2)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  if (__props.errors.status) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.status)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-4 float-end space-x-2"${_scopeId2}><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"${_scopeId2}> Submit </button><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"${_scopeId2}>Cancel </button></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "px-10 pb-10 my-10" }, [
                      createVNode("div", { class: "flex justify-between justify-items-center items-center py-2" }, [
                        createVNode(_component_DialogTitle, {
                          as: "h3",
                          class: "text-lg font-medium leading-6 text-gray-900"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Add New Developer ")
                          ]),
                          _: 1
                        }),
                        createVNode("div", null, [
                          createVNode("button", {
                            type: "button",
                            class: "text-5xl leading-6 text-gray-400 font-normal",
                            onClick: closeModal,
                            "data-bs-dismiss": "modal",
                            "aria-label": "Close"
                          }, " × ")
                        ])
                      ]),
                      createVNode("hr"),
                      createVNode("div", { class: "mt-2" }, [
                        createVNode("label", {
                          for: "name",
                          class: "text-lg font-semibold"
                        }, "Name"),
                        withDirectives(createVNode("input", {
                          type: "text",
                          class: "form-input px-4 py-3 rounded-md w-full my-2",
                          id: "name",
                          "onUpdate:modelValue": ($event) => unref(form).name = $event,
                          placeholder: "Enter Your Developer Name"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).name]
                        ]),
                        __props.errors.name ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.name), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-2" }, [
                        createVNode("label", {
                          for: "slug",
                          class: "text-lg font-semibold"
                        }, "Slug"),
                        withDirectives(createVNode("input", {
                          type: "text",
                          class: "form-input px-4 py-3 rounded-md w-full my-2",
                          id: "slug",
                          "onUpdate:modelValue": ($event) => unref(form).slug = $event,
                          placeholder: "Enter Your Developer Name"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).slug]
                        ]),
                        __props.errors.slug ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.slug), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-2" }, [
                        createVNode("label", {
                          for: "google_name",
                          class: "text-lg font-semibold"
                        }, "Google Name"),
                        withDirectives(createVNode("input", {
                          type: "text",
                          class: "form-input px-4 py-3 rounded-md w-full my-2",
                          id: "google_name",
                          "onUpdate:modelValue": ($event) => unref(form).google_name = $event,
                          placeholder: "Enter Your Developer Google Name"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).google_name]
                        ]),
                        __props.errors.google_name ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.google_name), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-2" }, [
                        createVNode("label", {
                          for: "google_url",
                          class: "text-lg font-semibold"
                        }, "Google Url"),
                        withDirectives(createVNode("input", {
                          type: "url",
                          class: "form-input px-4 py-3 rounded-md w-full my-2",
                          id: "google_url",
                          "onUpdate:modelValue": ($event) => unref(form).google_url = $event,
                          placeholder: "Enter Your Developer Google URL"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(form).google_url]
                        ]),
                        __props.errors.google_url ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.google_url), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-2" }, [
                        createVNode("label", {
                          for: "type",
                          class: "text-lg font-semibold"
                        }, "Type"),
                        createVNode(unref(VSelect), {
                          options: types,
                          reduce: (type2) => type2.id,
                          label: "name",
                          class: "style-chooser1 mt-2",
                          modelValue: unref(form).type,
                          "onUpdate:modelValue": ($event) => unref(form).type = $event
                        }, null, 8, ["reduce", "modelValue", "onUpdate:modelValue"]),
                        __props.errors.type ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.type), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-2 flex space-x-4 justify-items-center items-center" }, [
                        createVNode("label", {
                          for: "name",
                          class: "text-lg font-semibold"
                        }, "Publish Status"),
                        createVNode(unref(Switch), {
                          modelValue: unref(form).status,
                          "onUpdate:modelValue": ($event) => unref(form).status = $event,
                          as: "template"
                        }, {
                          default: withCtx(({ checked }) => [
                            createVNode("button", {
                              class: ["relative inline-flex h-6 w-11 items-center rounded-full", checked ? "bg-blue-600" : "bg-red-500"]
                            }, [
                              createVNode("span", { class: "sr-only" }, "Enable"),
                              createVNode("span", {
                                class: [checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"]
                              }, null, 2)
                            ], 2)
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"]),
                        __props.errors.status ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.status), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-4 float-end space-x-2" }, [
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                          onClick: submit
                        }, " Submit "),
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                          onClick: closeModal
                        }, "Cancel ")
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, { show: isShowUpdate.value }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="p-10 my-10"${_scopeId2}><div class="flex justify-between justify-items-center items-center py-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_DialogTitle, {
                    as: "h3",
                    class: "text-lg font-medium leading-6 text-gray-900"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Edit Developer `);
                      } else {
                        return [
                          createTextVNode(" Edit Developer ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div${_scopeId2}><button type="button" class="text-5xl leading-6 text-gray-400 font-normal" data-bs-dismiss="modal" aria-label="Close"${_scopeId2}> × </button></div></div><hr${_scopeId2}><div class="mt-2"${_scopeId2}><label for="name" class="text-lg font-semibold"${_scopeId2}>Name</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="name"${ssrRenderAttr("value", unref(editForm).name)} placeholder="Enter Your Developer Name"${_scopeId2}>`);
                  if (__props.errors.name) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.name)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="slug" class="text-lg font-semibold"${_scopeId2}>Slug</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="slug"${ssrRenderAttr("value", unref(editForm).slug)} placeholder="Enter Your Developer Name"${_scopeId2}>`);
                  if (__props.errors.slug) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.slug)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="google_name" class="text-lg font-semibold"${_scopeId2}>Google Name</label><input type="text" class="form-input px-4 py-3 rounded-md w-full my-2" id="google_name"${ssrRenderAttr("value", unref(editForm).google_name)} placeholder="Enter Your Developer Google Name"${_scopeId2}>`);
                  if (__props.errors.google_name) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.google_name)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="google_url" class="text-lg font-semibold"${_scopeId2}>Google Url</label><input type="url" class="form-input px-4 py-3 rounded-md w-full my-2" id="google_url"${ssrRenderAttr("value", unref(editForm).google_url)} placeholder="Enter Your Developer Google URL"${_scopeId2}>`);
                  if (__props.errors.google_url) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.google_url)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2"${_scopeId2}><label for="type" class="text-lg font-semibold"${_scopeId2}>Type</label>`);
                  _push3(ssrRenderComponent(unref(VSelect), {
                    options: types,
                    reduce: (type2) => type2.id,
                    label: "name",
                    class: "style-chooser1 mt-2",
                    modelValue: unref(editForm).type,
                    "onUpdate:modelValue": ($event) => unref(editForm).type = $event
                  }, null, _parent3, _scopeId2));
                  if (__props.errors.type) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.type)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-2 flex space-x-4 justify-items-center items-center"${_scopeId2}><label for="name" class="text-lg font-semibold"${_scopeId2}>Publish Status</label>`);
                  _push3(ssrRenderComponent(unref(Switch), {
                    modelValue: unref(editForm).status,
                    "onUpdate:modelValue": ($event) => unref(editForm).status = $event,
                    as: "template"
                  }, {
                    default: withCtx(({ checked }, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<button class="${ssrRenderClass([checked ? "bg-blue-600" : "bg-red-500", "relative inline-flex h-6 w-11 items-center rounded-full"])}"${_scopeId3}><span class="sr-only"${_scopeId3}>Enable</span><span class="${ssrRenderClass([checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"])}"${_scopeId3}></span></button>`);
                      } else {
                        return [
                          createVNode("button", {
                            class: ["relative inline-flex h-6 w-11 items-center rounded-full", checked ? "bg-blue-600" : "bg-red-500"]
                          }, [
                            createVNode("span", { class: "sr-only" }, "Enable"),
                            createVNode("span", {
                              class: [checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"]
                            }, null, 2)
                          ], 2)
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  if (__props.errors.status) {
                    _push3(`<span class="text-lg text-red-600 font-semibold"${_scopeId2}>${ssrInterpolate(__props.errors.status)}</span>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(`</div><div class="mt-4 float-end space-x-2"${_scopeId2}><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"${_scopeId2}> Submit </button><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"${_scopeId2}>Cancel </button></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "p-10 my-10" }, [
                      createVNode("div", { class: "flex justify-between justify-items-center items-center py-2" }, [
                        createVNode(_component_DialogTitle, {
                          as: "h3",
                          class: "text-lg font-medium leading-6 text-gray-900"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Edit Developer ")
                          ]),
                          _: 1
                        }),
                        createVNode("div", null, [
                          createVNode("button", {
                            type: "button",
                            class: "text-5xl leading-6 text-gray-400 font-normal",
                            onClick: closeUpdateModal,
                            "data-bs-dismiss": "modal",
                            "aria-label": "Close"
                          }, " × ")
                        ])
                      ]),
                      createVNode("hr"),
                      createVNode("div", { class: "mt-2" }, [
                        createVNode("label", {
                          for: "name",
                          class: "text-lg font-semibold"
                        }, "Name"),
                        withDirectives(createVNode("input", {
                          type: "text",
                          class: "form-input px-4 py-3 rounded-md w-full my-2",
                          id: "name",
                          "onUpdate:modelValue": ($event) => unref(editForm).name = $event,
                          placeholder: "Enter Your Developer Name"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(editForm).name]
                        ]),
                        __props.errors.name ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.name), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-2" }, [
                        createVNode("label", {
                          for: "slug",
                          class: "text-lg font-semibold"
                        }, "Slug"),
                        withDirectives(createVNode("input", {
                          type: "text",
                          class: "form-input px-4 py-3 rounded-md w-full my-2",
                          id: "slug",
                          "onUpdate:modelValue": ($event) => unref(editForm).slug = $event,
                          placeholder: "Enter Your Developer Name"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(editForm).slug]
                        ]),
                        __props.errors.slug ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.slug), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-2" }, [
                        createVNode("label", {
                          for: "google_name",
                          class: "text-lg font-semibold"
                        }, "Google Name"),
                        withDirectives(createVNode("input", {
                          type: "text",
                          class: "form-input px-4 py-3 rounded-md w-full my-2",
                          id: "google_name",
                          "onUpdate:modelValue": ($event) => unref(editForm).google_name = $event,
                          placeholder: "Enter Your Developer Google Name"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(editForm).google_name]
                        ]),
                        __props.errors.google_name ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.google_name), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-2" }, [
                        createVNode("label", {
                          for: "google_url",
                          class: "text-lg font-semibold"
                        }, "Google Url"),
                        withDirectives(createVNode("input", {
                          type: "url",
                          class: "form-input px-4 py-3 rounded-md w-full my-2",
                          id: "google_url",
                          "onUpdate:modelValue": ($event) => unref(editForm).google_url = $event,
                          placeholder: "Enter Your Developer Google URL"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(editForm).google_url]
                        ]),
                        __props.errors.google_url ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.google_url), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-2" }, [
                        createVNode("label", {
                          for: "type",
                          class: "text-lg font-semibold"
                        }, "Type"),
                        createVNode(unref(VSelect), {
                          options: types,
                          reduce: (type2) => type2.id,
                          label: "name",
                          class: "style-chooser1 mt-2",
                          modelValue: unref(editForm).type,
                          "onUpdate:modelValue": ($event) => unref(editForm).type = $event
                        }, null, 8, ["reduce", "modelValue", "onUpdate:modelValue"]),
                        __props.errors.type ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.type), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-2 flex space-x-4 justify-items-center items-center" }, [
                        createVNode("label", {
                          for: "name",
                          class: "text-lg font-semibold"
                        }, "Publish Status"),
                        createVNode(unref(Switch), {
                          modelValue: unref(editForm).status,
                          "onUpdate:modelValue": ($event) => unref(editForm).status = $event,
                          as: "template"
                        }, {
                          default: withCtx(({ checked }) => [
                            createVNode("button", {
                              class: ["relative inline-flex h-6 w-11 items-center rounded-full", checked ? "bg-blue-600" : "bg-red-500"]
                            }, [
                              createVNode("span", { class: "sr-only" }, "Enable"),
                              createVNode("span", {
                                class: [checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"]
                              }, null, 2)
                            ], 2)
                          ]),
                          _: 1
                        }, 8, ["modelValue", "onUpdate:modelValue"]),
                        __props.errors.status ? (openBlock(), createBlock("span", {
                          key: 0,
                          class: "text-lg text-red-600 font-semibold"
                        }, toDisplayString(__props.errors.status), 1)) : createCommentVNode("", true)
                      ]),
                      createVNode("div", { class: "mt-4 float-end space-x-2" }, [
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                          onClick: update
                        }, " Submit "),
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                          onClick: closeUpdateModal
                        }, "Cancel ")
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, { show: isShowDelete.value }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="pb-10 m-10 border-x border-t rounded-md"${_scopeId2}><div class="flex justify-between justify-items-center items-center p-1 mb-2 rounded-md"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_DialogTitle, {
                    as: "h3",
                    class: "text-lg font-medium leading-6 text-gray-900"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Delete Developer `);
                      } else {
                        return [
                          createTextVNode(" Delete Developer ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(`<div${_scopeId2}><button type="button" class="text-5xl leading-6 text-gray-400 font-normal" data-bs-dismiss="modal" aria-label="Close"${_scopeId2}> × </button></div></div><hr${_scopeId2}><div class="bg-red-100 p-5 text-red-700 space-y-2 rounded-md"${_scopeId2}><h2 class="flex space-x-2"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_ion_icon, {
                    name: "alert-circle-outline",
                    class: "text-3xl"
                  }, null, _parent3, _scopeId2));
                  _push3(` <span class="text-2xl"${_scopeId2}>Delete Developer</span></h2><p class="px-10"${_scopeId2}>You are sure you want to delete it?</p></div><div class="mt-4 space-x-2 float-end"${_scopeId2}><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"${_scopeId2}> Delete </button><button type="button" class="inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2"${_scopeId2}>Cancel </button></div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "pb-10 m-10 border-x border-t rounded-md" }, [
                      createVNode("div", { class: "flex justify-between justify-items-center items-center p-1 mb-2 rounded-md" }, [
                        createVNode(_component_DialogTitle, {
                          as: "h3",
                          class: "text-lg font-medium leading-6 text-gray-900"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Delete Developer ")
                          ]),
                          _: 1
                        }),
                        createVNode("div", null, [
                          createVNode("button", {
                            type: "button",
                            class: "text-5xl leading-6 text-gray-400 font-normal",
                            onClick: closeDeleteModal,
                            "data-bs-dismiss": "modal",
                            "aria-label": "Close"
                          }, " × ")
                        ])
                      ]),
                      createVNode("hr"),
                      createVNode("div", { class: "bg-red-100 p-5 text-red-700 space-y-2 rounded-md" }, [
                        createVNode("h2", { class: "flex space-x-2" }, [
                          createVNode(_component_ion_icon, {
                            name: "alert-circle-outline",
                            class: "text-3xl"
                          }),
                          createTextVNode(),
                          createVNode("span", { class: "text-2xl" }, "Delete Developer")
                        ]),
                        createVNode("p", { class: "px-10" }, "You are sure you want to delete it?")
                      ]),
                      createVNode("div", { class: "mt-4 space-x-2 float-end" }, [
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                          onClick: deleteDeveloper
                        }, " Delete "),
                        createVNode("button", {
                          type: "button",
                          class: "inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                          onClick: closeDeleteModal
                        }, "Cancel ")
                      ])
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg" }, [
                createVNode("div", { class: "p-6 text-gray-900" }, [
                  createVNode("div", {
                    id: "content",
                    class: ""
                  }, [
                    createVNode(_component_Header, { title: "main.developer-list" }),
                    createVNode("div", { class: "relative overflow-x-auto shadow-md sm:rounded-lg mt-5" }, [
                      createVNode("div", { class: "flex items-center justify-between flex-column flex-wrap md:flex-row space-y-4 md:space-y-0 pb-4 bg-white dark:bg-gray-900" }, [
                        createVNode("div", { class: "flex space-x-3" }, [
                          createVNode("div", null, [
                            createVNode("label", {
                              for: "table-search",
                              class: ""
                            }, "Search"),
                            createVNode("div", { class: "relative" }, [
                              createVNode("div", { class: "absolute inset-y-0 rtl:inset-r-0 start-0 flex items-center ps-3 pointer-events-none" }, [
                                (openBlock(), createBlock("svg", {
                                  class: "w-4 h-4 text-gray-500 dark:text-gray-400",
                                  "aria-hidden": "true",
                                  xmlns: "http://www.w3.org/2000/svg",
                                  fill: "none",
                                  viewBox: "0 0 20 20"
                                }, [
                                  createVNode("path", {
                                    stroke: "currentColor",
                                    "stroke-linecap": "round",
                                    "stroke-linejoin": "round",
                                    "stroke-width": "2",
                                    d: "m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
                                  })
                                ]))
                              ]),
                              withDirectives(createVNode("input", {
                                "onUpdate:modelValue": ($event) => search.value = $event,
                                type: "text",
                                id: "table-search-users",
                                class: "block p-2 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg w-80 bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500",
                                placeholder: "Search for Developer"
                              }, null, 8, ["onUpdate:modelValue"]), [
                                [vModelText, search.value]
                              ])
                            ])
                          ]),
                          createVNode("div", { class: "" }, [
                            createVNode("label", {
                              for: "type",
                              class: ""
                            }, "Status"),
                            createVNode(unref(VSelect), {
                              options: statusOptions,
                              reduce: (status2) => status2.id,
                              label: "name",
                              class: "style-chooser w-48",
                              modelValue: status.value,
                              "onUpdate:modelValue": ($event) => status.value = $event
                            }, null, 8, ["reduce", "modelValue", "onUpdate:modelValue"]),
                            __props.errors.type ? (openBlock(), createBlock("span", {
                              key: 0,
                              class: "text-lg text-red-600 font-semibold"
                            }, toDisplayString(__props.errors.type), 1)) : createCommentVNode("", true)
                          ])
                        ]),
                        createVNode("div")
                      ]),
                      __props.developers ? (openBlock(), createBlock("div", { key: 0 }, [
                        createVNode("table", {
                          class: "w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400",
                          style: { "width": "100%" }
                        }, [
                          createVNode("thead", { class: "text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400" }, [
                            createVNode("tr", null, [
                              createVNode("th", {
                                scope: "col",
                                class: "p-4",
                                style: { "width": "5%" }
                              }, " ID "),
                              createVNode("th", {
                                scope: "col",
                                class: "px-6 py-3",
                                style: { "width": "10%" }
                              }, " Icon "),
                              createVNode("th", {
                                scope: "col",
                                class: "px-6 py-3",
                                style: { "width": "25%" }
                              }, " Name "),
                              createVNode("th", {
                                scope: "col",
                                class: "px-6 py-3",
                                style: { "width": "25%" }
                              }, " slug "),
                              createVNode("th", {
                                scope: "col",
                                class: "px-6 py-3",
                                style: { "width": "10%" }
                              }, " Google Play "),
                              createVNode("th", {
                                scope: "col",
                                class: "px-6 py-3",
                                style: { "width": "10%" }
                              }, " Status "),
                              createVNode("th", {
                                scope: "col",
                                class: "px-6 py-3",
                                style: { "width": "15%" }
                              }, " Action ")
                            ])
                          ]),
                          createVNode("tbody", null, [
                            (openBlock(true), createBlock(Fragment, null, renderList(__props.developers.data, (developer, index) => {
                              return openBlock(), createBlock("tr", {
                                class: "bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600",
                                key: index
                              }, [
                                createVNode("td", { class: "p-4 text-lg font-semibold" }, toDisplayString(index + 1), 1),
                                createVNode("th", {
                                  scope: "row",
                                  class: "p-2"
                                }, toDisplayString(developer.icon), 1),
                                createVNode("th", {
                                  scope: "row",
                                  class: "p-2"
                                }, toDisplayString(developer.name), 1),
                                createVNode("td", { class: "px-2 py-2" }, toDisplayString(developer.slug), 1),
                                createVNode("td", { class: "px-2 py-2 capitalize" }, [
                                  createVNode("a", {
                                    target: "_blank",
                                    href: developer.google_url
                                  }, [
                                    createVNode(_component_ion_icon, {
                                      name: "logo-google-playstore",
                                      class: "text-2xl text-cyan-500 font-extrabold"
                                    })
                                  ], 8, ["href"])
                                ]),
                                createVNode("td", { class: "px-2 py-2" }, [
                                  developer.status ? (openBlock(), createBlock("span", {
                                    key: 0,
                                    class: "bg-green-600 text-white py-1 px-2 rounded-md font-normal"
                                  }, "Published")) : (openBlock(), createBlock("span", {
                                    key: 1,
                                    class: "bg-red-600 text-white py-1 px-2 rounded-md font-normal"
                                  }, "Unpublished"))
                                ]),
                                createVNode("td", { class: "px-2 py-2 space-x-3" }, [
                                  createVNode("a", {
                                    href: "#",
                                    class: "font-medium text-blue-600 dark:text-blue-500 hover:underline",
                                    onClick: ($event) => openUpdateModal(developer)
                                  }, [
                                    createVNode(_component_ion_icon, {
                                      name: "create",
                                      class: "pt-2",
                                      size: "large"
                                    })
                                  ], 8, ["onClick"]),
                                  createVNode("a", {
                                    href: "#",
                                    class: "font-medium text-blue-600 dark:text-blue-500 hover:underline",
                                    onClick: ($event) => openDeleteModal(developer)
                                  }, [
                                    createVNode(_component_ion_icon, {
                                      class: "pt-2 text-red-500",
                                      name: "trash",
                                      size: "large"
                                    })
                                  ], 8, ["onClick"])
                                ])
                              ]);
                            }), 128))
                          ])
                        ]),
                        createVNode(_sfc_main$2, {
                          meta: __props.developers.meta
                        }, null, 8, ["meta"])
                      ])) : (openBlock(), createBlock("div", {
                        key: 1,
                        class: "text-center text-4xl font-extrabold bg-gradient-to-t from-green-300 to-green-800 bg-clip-text text-transparent leading-normal"
                      }, " Data Not Found "))
                    ])
                  ]),
                  createVNode(_sfc_main$3, { show: isShow.value }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "px-10 pb-10 my-10" }, [
                        createVNode("div", { class: "flex justify-between justify-items-center items-center py-2" }, [
                          createVNode(_component_DialogTitle, {
                            as: "h3",
                            class: "text-lg font-medium leading-6 text-gray-900"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Add New Developer ")
                            ]),
                            _: 1
                          }),
                          createVNode("div", null, [
                            createVNode("button", {
                              type: "button",
                              class: "text-5xl leading-6 text-gray-400 font-normal",
                              onClick: closeModal,
                              "data-bs-dismiss": "modal",
                              "aria-label": "Close"
                            }, " × ")
                          ])
                        ]),
                        createVNode("hr"),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "name",
                            class: "text-lg font-semibold"
                          }, "Name"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "name",
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            placeholder: "Enter Your Developer Name"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).name]
                          ]),
                          __props.errors.name ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.name), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "slug",
                            class: "text-lg font-semibold"
                          }, "Slug"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "slug",
                            "onUpdate:modelValue": ($event) => unref(form).slug = $event,
                            placeholder: "Enter Your Developer Name"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).slug]
                          ]),
                          __props.errors.slug ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.slug), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "google_name",
                            class: "text-lg font-semibold"
                          }, "Google Name"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "google_name",
                            "onUpdate:modelValue": ($event) => unref(form).google_name = $event,
                            placeholder: "Enter Your Developer Google Name"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).google_name]
                          ]),
                          __props.errors.google_name ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.google_name), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "google_url",
                            class: "text-lg font-semibold"
                          }, "Google Url"),
                          withDirectives(createVNode("input", {
                            type: "url",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "google_url",
                            "onUpdate:modelValue": ($event) => unref(form).google_url = $event,
                            placeholder: "Enter Your Developer Google URL"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(form).google_url]
                          ]),
                          __props.errors.google_url ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.google_url), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "type",
                            class: "text-lg font-semibold"
                          }, "Type"),
                          createVNode(unref(VSelect), {
                            options: types,
                            reduce: (type2) => type2.id,
                            label: "name",
                            class: "style-chooser1 mt-2",
                            modelValue: unref(form).type,
                            "onUpdate:modelValue": ($event) => unref(form).type = $event
                          }, null, 8, ["reduce", "modelValue", "onUpdate:modelValue"]),
                          __props.errors.type ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.type), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2 flex space-x-4 justify-items-center items-center" }, [
                          createVNode("label", {
                            for: "name",
                            class: "text-lg font-semibold"
                          }, "Publish Status"),
                          createVNode(unref(Switch), {
                            modelValue: unref(form).status,
                            "onUpdate:modelValue": ($event) => unref(form).status = $event,
                            as: "template"
                          }, {
                            default: withCtx(({ checked }) => [
                              createVNode("button", {
                                class: ["relative inline-flex h-6 w-11 items-center rounded-full", checked ? "bg-blue-600" : "bg-red-500"]
                              }, [
                                createVNode("span", { class: "sr-only" }, "Enable"),
                                createVNode("span", {
                                  class: [checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"]
                                }, null, 2)
                              ], 2)
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"]),
                          __props.errors.status ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.status), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-4 float-end space-x-2" }, [
                          createVNode("button", {
                            type: "button",
                            class: "inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                            onClick: submit
                          }, " Submit "),
                          createVNode("button", {
                            type: "button",
                            class: "inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                            onClick: closeModal
                          }, "Cancel ")
                        ])
                      ])
                    ]),
                    _: 1
                  }, 8, ["show"]),
                  createVNode(_sfc_main$3, { show: isShowUpdate.value }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "p-10 my-10" }, [
                        createVNode("div", { class: "flex justify-between justify-items-center items-center py-2" }, [
                          createVNode(_component_DialogTitle, {
                            as: "h3",
                            class: "text-lg font-medium leading-6 text-gray-900"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Edit Developer ")
                            ]),
                            _: 1
                          }),
                          createVNode("div", null, [
                            createVNode("button", {
                              type: "button",
                              class: "text-5xl leading-6 text-gray-400 font-normal",
                              onClick: closeUpdateModal,
                              "data-bs-dismiss": "modal",
                              "aria-label": "Close"
                            }, " × ")
                          ])
                        ]),
                        createVNode("hr"),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "name",
                            class: "text-lg font-semibold"
                          }, "Name"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "name",
                            "onUpdate:modelValue": ($event) => unref(editForm).name = $event,
                            placeholder: "Enter Your Developer Name"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).name]
                          ]),
                          __props.errors.name ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.name), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "slug",
                            class: "text-lg font-semibold"
                          }, "Slug"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "slug",
                            "onUpdate:modelValue": ($event) => unref(editForm).slug = $event,
                            placeholder: "Enter Your Developer Name"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).slug]
                          ]),
                          __props.errors.slug ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.slug), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "google_name",
                            class: "text-lg font-semibold"
                          }, "Google Name"),
                          withDirectives(createVNode("input", {
                            type: "text",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "google_name",
                            "onUpdate:modelValue": ($event) => unref(editForm).google_name = $event,
                            placeholder: "Enter Your Developer Google Name"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).google_name]
                          ]),
                          __props.errors.google_name ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.google_name), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "google_url",
                            class: "text-lg font-semibold"
                          }, "Google Url"),
                          withDirectives(createVNode("input", {
                            type: "url",
                            class: "form-input px-4 py-3 rounded-md w-full my-2",
                            id: "google_url",
                            "onUpdate:modelValue": ($event) => unref(editForm).google_url = $event,
                            placeholder: "Enter Your Developer Google URL"
                          }, null, 8, ["onUpdate:modelValue"]), [
                            [vModelText, unref(editForm).google_url]
                          ]),
                          __props.errors.google_url ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.google_url), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2" }, [
                          createVNode("label", {
                            for: "type",
                            class: "text-lg font-semibold"
                          }, "Type"),
                          createVNode(unref(VSelect), {
                            options: types,
                            reduce: (type2) => type2.id,
                            label: "name",
                            class: "style-chooser1 mt-2",
                            modelValue: unref(editForm).type,
                            "onUpdate:modelValue": ($event) => unref(editForm).type = $event
                          }, null, 8, ["reduce", "modelValue", "onUpdate:modelValue"]),
                          __props.errors.type ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.type), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-2 flex space-x-4 justify-items-center items-center" }, [
                          createVNode("label", {
                            for: "name",
                            class: "text-lg font-semibold"
                          }, "Publish Status"),
                          createVNode(unref(Switch), {
                            modelValue: unref(editForm).status,
                            "onUpdate:modelValue": ($event) => unref(editForm).status = $event,
                            as: "template"
                          }, {
                            default: withCtx(({ checked }) => [
                              createVNode("button", {
                                class: ["relative inline-flex h-6 w-11 items-center rounded-full", checked ? "bg-blue-600" : "bg-red-500"]
                              }, [
                                createVNode("span", { class: "sr-only" }, "Enable"),
                                createVNode("span", {
                                  class: [checked ? "translate-x-6" : "translate-x-1", "inline-block h-4 w-4 transform rounded-full bg-white transition"]
                                }, null, 2)
                              ], 2)
                            ]),
                            _: 1
                          }, 8, ["modelValue", "onUpdate:modelValue"]),
                          __props.errors.status ? (openBlock(), createBlock("span", {
                            key: 0,
                            class: "text-lg text-red-600 font-semibold"
                          }, toDisplayString(__props.errors.status), 1)) : createCommentVNode("", true)
                        ]),
                        createVNode("div", { class: "mt-4 float-end space-x-2" }, [
                          createVNode("button", {
                            type: "button",
                            class: "inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                            onClick: update
                          }, " Submit "),
                          createVNode("button", {
                            type: "button",
                            class: "inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                            onClick: closeUpdateModal
                          }, "Cancel ")
                        ])
                      ])
                    ]),
                    _: 1
                  }, 8, ["show"]),
                  createVNode(_sfc_main$3, { show: isShowDelete.value }, {
                    default: withCtx(() => [
                      createVNode("div", { class: "pb-10 m-10 border-x border-t rounded-md" }, [
                        createVNode("div", { class: "flex justify-between justify-items-center items-center p-1 mb-2 rounded-md" }, [
                          createVNode(_component_DialogTitle, {
                            as: "h3",
                            class: "text-lg font-medium leading-6 text-gray-900"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Delete Developer ")
                            ]),
                            _: 1
                          }),
                          createVNode("div", null, [
                            createVNode("button", {
                              type: "button",
                              class: "text-5xl leading-6 text-gray-400 font-normal",
                              onClick: closeDeleteModal,
                              "data-bs-dismiss": "modal",
                              "aria-label": "Close"
                            }, " × ")
                          ])
                        ]),
                        createVNode("hr"),
                        createVNode("div", { class: "bg-red-100 p-5 text-red-700 space-y-2 rounded-md" }, [
                          createVNode("h2", { class: "flex space-x-2" }, [
                            createVNode(_component_ion_icon, {
                              name: "alert-circle-outline",
                              class: "text-3xl"
                            }),
                            createTextVNode(),
                            createVNode("span", { class: "text-2xl" }, "Delete Developer")
                          ]),
                          createVNode("p", { class: "px-10" }, "You are sure you want to delete it?")
                        ]),
                        createVNode("div", { class: "mt-4 space-x-2 float-end" }, [
                          createVNode("button", {
                            type: "button",
                            class: "inline-flex justify-center rounded-md border border-transparent bg-blue-100 px-4 py-2 text-sm font-semibold text-blue-900 hover:bg-blue-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                            onClick: deleteDeveloper
                          }, " Delete "),
                          createVNode("button", {
                            type: "button",
                            class: "inline-flex justify-center rounded-md border border-transparent bg-red-500 px-4 py-2 text-sm font-semibold text-white hover:bg-red-400 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2",
                            onClick: closeDeleteModal
                          }, "Cancel ")
                        ])
                      ])
                    ]),
                    _: 1
                  }, 8, ["show"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Backend/Developer/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
