import { ref, resolveComponent, unref, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, createCommentVNode, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderStyle, ssrInterpolate, ssrRenderAttr, ssrRenderClass, ssrRenderList } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./FrontendLayout-CAfbY_H6.js";
import { Head, Link } from "@inertiajs/vue3";
/* empty css                  */
import vue3StarRatings from "vue3-star-ratings";
import VueEasyLightbox from "vue-easy-lightbox/dist/external-css/vue-easy-lightbox.esm.min.js";
/* empty css                           */
import _sfc_main$2 from "./Related-C0hxDLky.js";
import _sfc_main$3 from "./Review-kOfRqTlR.js";
import "./ApplicationLogo-3H3I4iid.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./NavLink-CscBEwLF.js";
import "@headlessui/vue";
import "./TextInput-D7U8fbl4.js";
import "./TopRated-BRRuMLjo.js";
import "vue3-emoji-picker";
import "./InputLabel-Dkex7vHI.js";
import "./Modal-_hjahxgY.js";
const _sfc_main = {
  __name: "View",
  __ssrInlineRender: true,
  props: {
    app: Object,
    related_apps: Object,
    developer_apps: Object
  },
  setup(__props) {
    const props = __props;
    const rating = ref(props.app.review_count.data.rating > 0 ? props.app.review_count.data.rating : props.app.rating);
    const pluck = (arr, key) => arr.map((i) => i[key]);
    const photos = pluck(props.app.screenshots, "photo");
    const visibleRef = ref(false);
    const indexRef = ref(0);
    const showImg = (index) => {
      indexRef.value = index;
      visibleRef.value = true;
    };
    const onHide = () => visibleRef.value = false;
    const description = ref("max-h-[160px] overflow-hidden");
    const showText = () => {
      if (description.value === "max-h-full") {
        description.value = "max-h-[160px] overflow-hidden";
      } else {
        description.value = "max-h-full";
      }
    };
    const isShow = ref(false);
    const openModal = () => {
      isShow.value = true;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ion_icon = resolveComponent("ion-icon");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<title${_scopeId}>Home</title>`);
          } else {
            return [
              createVNode("title", null, "Home")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n;
          if (_push2) {
            _push2(`<div class="overflow-hidden bg-white shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6 text-gray-900 md:bg-no-repeat bg-right md:bg-contain rounded-md" style="${ssrRenderStyle(`background-image: url('${__props.app.cover_image}')`)}"${_scopeId}><div class="flex"${_scopeId}><span class="flex items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              class: "text-cyan-500 font-semibold hover:text-indigo-600",
              href: _ctx.route("home")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Home`);
                } else {
                  return [
                    createTextVNode("Home")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(` `);
            _push2(ssrRenderComponent(_component_ion_icon, {
              name: "chevron-forward-outline",
              class: "text-2xl text-cyan-500 font-extrabold"
            }, null, _parent2, _scopeId));
            _push2(`</span><span class="flex items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              class: "text-cyan-500 font-semibold hover:text-indigo-600",
              href: _ctx.route("app.index")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Apps`);
                } else {
                  return [
                    createTextVNode("Apps")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(` `);
            _push2(ssrRenderComponent(_component_ion_icon, {
              name: "chevron-forward-outline",
              class: "text-2xl text-cyan-500 font-extrabold"
            }, null, _parent2, _scopeId));
            _push2(`</span><span class="flex items-center"${_scopeId}>`);
            if (__props.app.category) {
              _push2(ssrRenderComponent(unref(Link), {
                class: "text-cyan-500 font-semibold hover:text-indigo-600",
                href: _ctx.route("categories.view", __props.app.category)
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  var _a2, _b2;
                  if (_push3) {
                    _push3(`${ssrInterpolate((_a2 = __props.app.category) == null ? void 0 : _a2.name)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString((_b2 = __props.app.category) == null ? void 0 : _b2.name), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(` `);
            if (__props.app.category) {
              _push2(ssrRenderComponent(_component_ion_icon, {
                name: "chevron-forward-outline",
                class: "text-2xl text-cyan-500 font-extrabold"
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</span><span class="flex items-center"${_scopeId}>${ssrInterpolate(__props.app.title)}</span></div><div class="flex space-x-3 mt-5"${_scopeId}><div class="rounded-md"${_scopeId}><img${ssrRenderAttr("src", __props.app.icon)} alt="" width="240" class="object-cover rounded-md"${_scopeId}><div class="text-center capitalize text-5xl shadow-md bg-emerald-500 text-white rounded-md"${_scopeId}>${ssrInterpolate(__props.app.type)}</div></div><div class="flex flex-col space-y-2"${_scopeId}><h1 class="text-5xl"${_scopeId}>${ssrInterpolate(__props.app.title)}</h1><span class="text-lg"${_scopeId}>Category: `);
            if (__props.app.category) {
              _push2(`<a class="text-indigo-600 font-semibold"${ssrRenderAttr("href", _ctx.route("categories.view", (_a = __props.app) == null ? void 0 : _a.category))}${_scopeId}>${ssrInterpolate((_c = (_b = __props.app) == null ? void 0 : _b.category) == null ? void 0 : _c.name)}</a>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</span>`);
            if ((_d = __props.app) == null ? void 0 : _d.developer) {
              _push2(`<span class="text-lg"${_scopeId}>Developer: <a class="text-indigo-600 font-semibold"${ssrRenderAttr("href", _ctx.route("developers.view", (_e = __props.app) == null ? void 0 : _e.developer))}${_scopeId}>${ssrInterpolate((_g = (_f = __props.app) == null ? void 0 : _f.developer) == null ? void 0 : _g.name)}</a></span>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div class="flex space-x-3 items-center"${_scopeId}><span class="text-4xl"${_scopeId}>${ssrInterpolate(rating.value)}</span>`);
            _push2(ssrRenderComponent(unref(vue3StarRatings), {
              modelValue: rating.value,
              "onUpdate:modelValue": ($event) => rating.value = $event,
              "star-size": "40",
              inactiveColor: "#cbd5e1",
              disableClick: true
            }, null, _parent2, _scopeId));
            _push2(`</div><span class="text-lg mt-5 flex space-x-2"${_scopeId}><span class="text-lg"${_scopeId}>Google Play: </span><a class="text-indigo-600 font-semibold"${ssrRenderAttr("href", __props.app.url)}${_scopeId}>`);
            _push2(ssrRenderComponent(_component_ion_icon, {
              name: "logo-google-playstore",
              class: "text-2xl text-cyan-500 font-extrabold"
            }, null, _parent2, _scopeId));
            _push2(`</a></span><span class="text-lg mt-5"${_scopeId}><span class="text-lg"${_scopeId}> Updated On: </span> ${ssrInterpolate(__props.app.updated_at)}</span><div${_scopeId}>`);
            if (__props.app.trailer) {
              _push2(`<button class="text-white bg-gray-800 text-lg py-2 px-4 rounded-lg justify-center items-center flex"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_ion_icon, {
                name: "play-outline",
                class: "text-white text-xl pr-1"
              }, null, _parent2, _scopeId));
              _push2(` <span${_scopeId}>Trailer</span></button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div></div></div><div class="overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2"${_scopeId}>`);
            if (__props.app.description) {
              _push2(`<div class="py-4 px-5"${_scopeId}><h3 class="text-3xl py-2"${_scopeId}>About ${ssrInterpolate(__props.app.title)}</h3><p class="${ssrRenderClass([description.value, "text-lg"])}"${_scopeId}>${__props.app.description ?? ""}</p><button class="text-indigo-500 font-semibold mt-5"${_scopeId}>${ssrInterpolate(description.value === "max-h-full" ? "Show Less" : "Show More")}</button></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2"${_scopeId}>`);
            if (__props.app.whats_new) {
              _push2(`<div class="py-4 px-5"${_scopeId}><h3${_scopeId}>What&#39;s New</h3><p class="text-lg"${_scopeId}>${__props.app.whats_new ?? ""}</p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2"${_scopeId}>`);
            if (unref(photos).length) {
              _push2(`<div class="mt-5"${_scopeId}><div class="flex gap-4 overflow-x-scroll w-full bg-blue-50"${_scopeId}><!--[-->`);
              ssrRenderList(unref(photos), (src, index) => {
                _push2(`<div class="pic"${_scopeId}><img${ssrRenderAttr("src", src)} class="mx-2 min-w-[240px] border rounded-md"${_scopeId}></div>`);
              });
              _push2(`<!--]--></div>`);
              _push2(ssrRenderComponent(unref(VueEasyLightbox), {
                visible: visibleRef.value,
                imgs: unref(photos),
                index: indexRef.value,
                onHide,
                class: ""
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2"${_scopeId}>`);
            if (__props.app.versions.length) {
              _push2(`<div class="py-4 px-5"${_scopeId}><h3 class="mb-4 text-2xl"${_scopeId}>Versions History of ${ssrInterpolate(__props.app.title)}</h3><div class="divide-y py-5"${_scopeId}><!--[-->`);
              ssrRenderList(__props.app.versions.slice(0, 3), (version) => {
                _push2(`<div class=""${_scopeId}><div class="text-lg flex justify-between"${_scopeId}><a href="" class="py-2 text-gray-700 hover:text-indigo-700 hover:font-semibold"${_scopeId}><h3${_scopeId}>v${ssrInterpolate(version.version)} (${ssrInterpolate(version.version_code)})</h3><div class="space-x-6 text-gray-400"${_scopeId}><span${_scopeId}>${ssrInterpolate(version.file_size)}</span><span${_scopeId}>${ssrInterpolate(version.date_format)}</span></div></a><div class="flex items-center justify-items-center"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  href: _ctx.route("app.view.download", [__props.app, version]),
                  class: "px-3 py-1 bg-green-500 text-white flex items-center space-x-2 hover:bg-green-400 rounded-md"
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(_component_ion_icon, { name: "arrow-down-circle-outline" }, null, _parent3, _scopeId2));
                      _push3(` <span${_scopeId2}>Download</span>`);
                    } else {
                      return [
                        createVNode(_component_ion_icon, { name: "arrow-down-circle-outline" }),
                        createTextVNode(),
                        createVNode("span", null, "Download")
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
                _push2(`</div></div></div>`);
              });
              _push2(`<!--]--></div>`);
              if (__props.app.versions.length > 3) {
                _push2(`<div class="text-center pt-5 border-t"${_scopeId}>`);
                _push2(ssrRenderComponent(unref(Link), {
                  class: "px-32 py-2 bg-gray-50 border-2 border-green-500 hover:border-green-200 rounded-md hover:bg-green-500 hover:text-gray-50 transition-all duration-300",
                  href: _ctx.route("app.view.versions", __props.app.slug)
                }, {
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(` All Versions `);
                    } else {
                      return [
                        createTextVNode(" All Versions ")
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
                _push2(`</div>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div class="overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2"${_scopeId}><div class="mt-5"${_scopeId}>`);
            if (__props.related_apps.length > 0) {
              _push2(ssrRenderComponent(_sfc_main$2, {
                apps: __props.related_apps,
                label: "Related Apps"
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (__props.developer_apps.length > 0) {
              _push2(ssrRenderComponent(_sfc_main$2, {
                apps: __props.developer_apps,
                label: "Developer App"
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              app: __props.app,
              label: "Developer App"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg" }, [
                createVNode("div", {
                  class: "p-6 text-gray-900 md:bg-no-repeat bg-right md:bg-contain rounded-md",
                  style: `background-image: url('${__props.app.cover_image}')`
                }, [
                  createVNode("div", { class: "flex" }, [
                    createVNode("span", { class: "flex items-center" }, [
                      createVNode(unref(Link), {
                        class: "text-cyan-500 font-semibold hover:text-indigo-600",
                        href: _ctx.route("home")
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Home")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createTextVNode(),
                      createVNode(_component_ion_icon, {
                        name: "chevron-forward-outline",
                        class: "text-2xl text-cyan-500 font-extrabold"
                      })
                    ]),
                    createVNode("span", { class: "flex items-center" }, [
                      createVNode(unref(Link), {
                        class: "text-cyan-500 font-semibold hover:text-indigo-600",
                        href: _ctx.route("app.index")
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Apps")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createTextVNode(),
                      createVNode(_component_ion_icon, {
                        name: "chevron-forward-outline",
                        class: "text-2xl text-cyan-500 font-extrabold"
                      })
                    ]),
                    createVNode("span", { class: "flex items-center" }, [
                      __props.app.category ? (openBlock(), createBlock(unref(Link), {
                        key: 0,
                        class: "text-cyan-500 font-semibold hover:text-indigo-600",
                        href: _ctx.route("categories.view", __props.app.category)
                      }, {
                        default: withCtx(() => {
                          var _a2;
                          return [
                            createTextVNode(toDisplayString((_a2 = __props.app.category) == null ? void 0 : _a2.name), 1)
                          ];
                        }),
                        _: 1
                      }, 8, ["href"])) : createCommentVNode("", true),
                      createTextVNode(),
                      __props.app.category ? (openBlock(), createBlock(_component_ion_icon, {
                        key: 1,
                        name: "chevron-forward-outline",
                        class: "text-2xl text-cyan-500 font-extrabold"
                      })) : createCommentVNode("", true)
                    ]),
                    createVNode("span", { class: "flex items-center" }, toDisplayString(__props.app.title), 1)
                  ]),
                  createVNode("div", { class: "flex space-x-3 mt-5" }, [
                    createVNode("div", { class: "rounded-md" }, [
                      createVNode("img", {
                        src: __props.app.icon,
                        alt: "",
                        width: "240",
                        class: "object-cover rounded-md"
                      }, null, 8, ["src"]),
                      createVNode("div", { class: "text-center capitalize text-5xl shadow-md bg-emerald-500 text-white rounded-md" }, toDisplayString(__props.app.type), 1)
                    ]),
                    createVNode("div", { class: "flex flex-col space-y-2" }, [
                      createVNode("h1", { class: "text-5xl" }, toDisplayString(__props.app.title), 1),
                      createVNode("span", { class: "text-lg" }, [
                        createTextVNode("Category: "),
                        __props.app.category ? (openBlock(), createBlock("a", {
                          key: 0,
                          class: "text-indigo-600 font-semibold",
                          href: _ctx.route("categories.view", (_h = __props.app) == null ? void 0 : _h.category)
                        }, toDisplayString((_j = (_i = __props.app) == null ? void 0 : _i.category) == null ? void 0 : _j.name), 9, ["href"])) : createCommentVNode("", true)
                      ]),
                      ((_k = __props.app) == null ? void 0 : _k.developer) ? (openBlock(), createBlock("span", {
                        key: 0,
                        class: "text-lg"
                      }, [
                        createTextVNode("Developer: "),
                        createVNode("a", {
                          class: "text-indigo-600 font-semibold",
                          href: _ctx.route("developers.view", (_l = __props.app) == null ? void 0 : _l.developer)
                        }, toDisplayString((_n = (_m = __props.app) == null ? void 0 : _m.developer) == null ? void 0 : _n.name), 9, ["href"])
                      ])) : createCommentVNode("", true),
                      createVNode("div", { class: "flex space-x-3 items-center" }, [
                        createVNode("span", { class: "text-4xl" }, toDisplayString(rating.value), 1),
                        createVNode(unref(vue3StarRatings), {
                          modelValue: rating.value,
                          "onUpdate:modelValue": ($event) => rating.value = $event,
                          "star-size": "40",
                          inactiveColor: "#cbd5e1",
                          disableClick: true
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ]),
                      createVNode("span", { class: "text-lg mt-5 flex space-x-2" }, [
                        createVNode("span", { class: "text-lg" }, "Google Play: "),
                        createVNode("a", {
                          class: "text-indigo-600 font-semibold",
                          href: __props.app.url
                        }, [
                          createVNode(_component_ion_icon, {
                            name: "logo-google-playstore",
                            class: "text-2xl text-cyan-500 font-extrabold"
                          })
                        ], 8, ["href"])
                      ]),
                      createVNode("span", { class: "text-lg mt-5" }, [
                        createVNode("span", { class: "text-lg" }, " Updated On: "),
                        createTextVNode(" " + toDisplayString(__props.app.updated_at), 1)
                      ]),
                      createVNode("div", null, [
                        __props.app.trailer ? (openBlock(), createBlock("button", {
                          key: 0,
                          class: "text-white bg-gray-800 text-lg py-2 px-4 rounded-lg justify-center items-center flex",
                          onClick: openModal
                        }, [
                          createVNode(_component_ion_icon, {
                            name: "play-outline",
                            class: "text-white text-xl pr-1"
                          }),
                          createTextVNode(),
                          createVNode("span", null, "Trailer")
                        ])) : createCommentVNode("", true)
                      ])
                    ])
                  ])
                ], 4)
              ]),
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2" }, [
                __props.app.description ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "py-4 px-5"
                }, [
                  createVNode("h3", { class: "text-3xl py-2" }, "About " + toDisplayString(__props.app.title), 1),
                  createVNode("p", {
                    class: ["text-lg", description.value],
                    innerHTML: __props.app.description
                  }, null, 10, ["innerHTML"]),
                  createVNode("button", {
                    onClick: showText,
                    class: "text-indigo-500 font-semibold mt-5"
                  }, toDisplayString(description.value === "max-h-full" ? "Show Less" : "Show More"), 1)
                ])) : createCommentVNode("", true)
              ]),
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2" }, [
                __props.app.whats_new ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "py-4 px-5"
                }, [
                  createVNode("h3", null, "What's New"),
                  createVNode("p", {
                    class: "text-lg",
                    innerHTML: __props.app.whats_new
                  }, null, 8, ["innerHTML"])
                ])) : createCommentVNode("", true)
              ]),
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2" }, [
                unref(photos).length ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "mt-5"
                }, [
                  createVNode("div", { class: "flex gap-4 overflow-x-scroll w-full bg-blue-50" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(photos), (src, index) => {
                      return openBlock(), createBlock("div", {
                        key: index,
                        class: "pic",
                        onClick: () => showImg(index)
                      }, [
                        createVNode("img", {
                          src,
                          class: "mx-2 min-w-[240px] border rounded-md"
                        }, null, 8, ["src"])
                      ], 8, ["onClick"]);
                    }), 128))
                  ]),
                  createVNode(unref(VueEasyLightbox), {
                    visible: visibleRef.value,
                    imgs: unref(photos),
                    index: indexRef.value,
                    onHide,
                    class: ""
                  }, null, 8, ["visible", "imgs", "index"])
                ])) : createCommentVNode("", true)
              ]),
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2" }, [
                __props.app.versions.length ? (openBlock(), createBlock("div", {
                  key: 0,
                  class: "py-4 px-5"
                }, [
                  createVNode("h3", { class: "mb-4 text-2xl" }, "Versions History of " + toDisplayString(__props.app.title), 1),
                  createVNode("div", { class: "divide-y py-5" }, [
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.app.versions.slice(0, 3), (version) => {
                      return openBlock(), createBlock("div", { class: "" }, [
                        createVNode("div", { class: "text-lg flex justify-between" }, [
                          createVNode("a", {
                            href: "",
                            class: "py-2 text-gray-700 hover:text-indigo-700 hover:font-semibold"
                          }, [
                            createVNode("h3", null, "v" + toDisplayString(version.version) + " (" + toDisplayString(version.version_code) + ")", 1),
                            createVNode("div", { class: "space-x-6 text-gray-400" }, [
                              createVNode("span", null, toDisplayString(version.file_size), 1),
                              createVNode("span", null, toDisplayString(version.date_format), 1)
                            ])
                          ]),
                          createVNode("div", { class: "flex items-center justify-items-center" }, [
                            createVNode(unref(Link), {
                              href: _ctx.route("app.view.download", [__props.app, version]),
                              class: "px-3 py-1 bg-green-500 text-white flex items-center space-x-2 hover:bg-green-400 rounded-md"
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_ion_icon, { name: "arrow-down-circle-outline" }),
                                createTextVNode(),
                                createVNode("span", null, "Download")
                              ]),
                              _: 2
                            }, 1032, ["href"])
                          ])
                        ])
                      ]);
                    }), 256))
                  ]),
                  __props.app.versions.length > 3 ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "text-center pt-5 border-t"
                  }, [
                    createVNode(unref(Link), {
                      class: "px-32 py-2 bg-gray-50 border-2 border-green-500 hover:border-green-200 rounded-md hover:bg-green-500 hover:text-gray-50 transition-all duration-300",
                      href: _ctx.route("app.view.versions", __props.app.slug)
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" All Versions ")
                      ]),
                      _: 1
                    }, 8, ["href"])
                  ])) : createCommentVNode("", true)
                ])) : createCommentVNode("", true)
              ]),
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg mt-2" }, [
                createVNode("div", { class: "mt-5" }, [
                  __props.related_apps.length > 0 ? (openBlock(), createBlock(_sfc_main$2, {
                    key: 0,
                    apps: __props.related_apps,
                    label: "Related Apps"
                  }, null, 8, ["apps"])) : createCommentVNode("", true),
                  __props.developer_apps.length > 0 ? (openBlock(), createBlock(_sfc_main$2, {
                    key: 1,
                    apps: __props.developer_apps,
                    label: "Developer App"
                  }, null, 8, ["apps"])) : createCommentVNode("", true)
                ])
              ]),
              createVNode(_sfc_main$3, {
                app: __props.app,
                label: "Developer App"
              }, null, 8, ["app"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/App/View.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
