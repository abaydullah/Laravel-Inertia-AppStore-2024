import { resolveComponent, unref, withCtx, createVNode, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { Head, Link } from "@inertiajs/vue3";
import _sfc_main$2 from "./Card-dO7liSGx.js";
import { _ as _sfc_main$1 } from "./FrontendLayout-CAfbY_H6.js";
import "vue3-star-ratings";
import "./ApplicationLogo-3H3I4iid.js";
import "./_plugin-vue_export-helper-1tPrXgE0.js";
import "./NavLink-CscBEwLF.js";
import "@headlessui/vue";
import "./TextInput-D7U8fbl4.js";
import "./TopRated-BRRuMLjo.js";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    apps: Array
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ion_icon = resolveComponent("ion-icon");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<title${_scopeId}>Search Result</title>`);
          } else {
            return [
              createVNode("title", null, "Search Result")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="overflow-hidden bg-white shadow-sm sm:rounded-lg"${_scopeId}><div class="p-6 text-gray-900"${_scopeId}><div class="flex"${_scopeId}><span class="flex items-center"${_scopeId}>`);
            _push2(ssrRenderComponent(unref(Link), {
              class: "text-cyan-500 font-semibold hover:text-indigo-600",
              href: _ctx.route("home")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`Home`);
                } else {
                  return [
                    createTextVNode("Home")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(` `);
            _push2(ssrRenderComponent(_component_ion_icon, {
              name: "chevron-forward-outline",
              class: "text-2xl text-cyan-500 font-extrabold"
            }, null, _parent2, _scopeId));
            _push2(`</span><span class="flex items-center"${_scopeId}><span class="font-semibold"${_scopeId}>Search</span></span></div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, { apps: __props.apps }, null, _parent2, _scopeId));
            _push2(`</div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "overflow-hidden bg-white shadow-sm sm:rounded-lg" }, [
                createVNode("div", { class: "p-6 text-gray-900" }, [
                  createVNode("div", { class: "flex" }, [
                    createVNode("span", { class: "flex items-center" }, [
                      createVNode(unref(Link), {
                        class: "text-cyan-500 font-semibold hover:text-indigo-600",
                        href: _ctx.route("home")
                      }, {
                        default: withCtx(() => [
                          createTextVNode("Home")
                        ]),
                        _: 1
                      }, 8, ["href"]),
                      createTextVNode(),
                      createVNode(_component_ion_icon, {
                        name: "chevron-forward-outline",
                        class: "text-2xl text-cyan-500 font-extrabold"
                      })
                    ]),
                    createVNode("span", { class: "flex items-center" }, [
                      createVNode("span", { class: "font-semibold" }, "Search")
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$2, { apps: __props.apps }, null, 8, ["apps"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/Search/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
