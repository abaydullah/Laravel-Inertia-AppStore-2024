import { mergeProps, unref, withCtx, createVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderComponent, ssrRenderAttr } from "vue/server-renderer";
import vue3StarRatings from "vue3-star-ratings";
import { Link } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "Card",
  __ssrInlineRender: true,
  props: {
    apps: Object,
    label: String
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-5 shadow-md" }, _attrs))}><div class="flex justify-between p-2 border-x-8 border-y-2 bg-emerald-700 ring-2 outline-4 rounded-md font-semibold text-white mb-5"><h2 class="">${ssrInterpolate(__props.label)}</h2><a href="#" class="">More</a></div><div class="grid md:grid-cols-6 grid-cols-2 gap-5"><!--[-->`);
      ssrRenderList(__props.apps.data, (app) => {
        _push(`<div><div class="">`);
        _push(ssrRenderComponent(unref(Link), {
          href: _ctx.route("app.view", app)
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="shadow-sm rounded p-1 hover:bg-gray-200 border ring-2 hover:border-amber-300 hover:ring-yellow-500 transition-all duration-200 hover:ring-4"${_scopeId}><div class="flex flex-col items-center space-y-2"${_scopeId}><img${ssrRenderAttr("src", app.icon)} alt="" width="120" class="rounded object-cover"${_scopeId}><h5 class="text-sm text-center"${_scopeId}>${ssrInterpolate(app.title.substring(0, 12))}</h5></div><div class="flex justify-center"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(vue3StarRatings), {
                "star-size": "12",
                modelValue: app.rating,
                "onUpdate:modelValue": ($event) => app.rating = $event,
                "disable-click": "",
                inactiveColor: "#cbd5e1"
              }, null, _parent2, _scopeId));
              _push2(`</div></div>`);
            } else {
              return [
                createVNode("div", { class: "shadow-sm rounded p-1 hover:bg-gray-200 border ring-2 hover:border-amber-300 hover:ring-yellow-500 transition-all duration-200 hover:ring-4" }, [
                  createVNode("div", { class: "flex flex-col items-center space-y-2" }, [
                    createVNode("img", {
                      src: app.icon,
                      alt: "",
                      width: "120",
                      class: "rounded object-cover"
                    }, null, 8, ["src"]),
                    createVNode("h5", { class: "text-sm text-center" }, toDisplayString(app.title.substring(0, 12)), 1)
                  ]),
                  createVNode("div", { class: "flex justify-center" }, [
                    createVNode(unref(vue3StarRatings), {
                      "star-size": "12",
                      modelValue: app.rating,
                      "onUpdate:modelValue": ($event) => app.rating = $event,
                      "disable-click": "",
                      inactiveColor: "#cbd5e1"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ])
                ])
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div></div>`);
      });
      _push(`<!--]--></div><div class="flex justify-center items-center mt-5">`);
      if ((_a = __props.apps.links) == null ? void 0 : _a.next) {
        _push(`<button class="bg-blue-700 py-1 px-3 text-white rounded-md hover:bg-blue-500 font-semibold">See More</button>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Frontend/App/Partials/Card.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
